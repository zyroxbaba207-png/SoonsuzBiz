import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  Image as ImageIcon,
  Film,
  MapPin,
  Music,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { api } from '../api/client';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  defaultType?: 'post' | 'reel';
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  defaultType = 'post',
}) => {
  const [contentType, setContentType] = useState<'post' | 'reel'>(defaultType);
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [location, setLocation] = useState('');
  const [soundTitle, setSoundTitle] = useState('');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;

    if (contentType === 'reel' && !selected.type.startsWith('video')) {
      setError('Reels akışı için lütfen dikey bir video dosyası seçin.');
      return;
    }

    setFile(selected);
    setError(null);
    setPreviewUrl(URL.createObjectURL(selected));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      setError('Lütfen bir fotoğraf veya video seçin.');
      return;
    }

    setUploading(true);
    setError(null);

    try {
      const uploaded = await api.uploadFile(file);

      if (contentType === 'reel') {
        await api.createReel({
          videoUrl: uploaded.url,
          caption,
          soundTitle: soundTitle || 'SonsuzBiz Aşk Melodisi ❤️',
        });
      } else {
        const isVideo = file.type.startsWith('video');
        await api.createPost({
          mediaUrl: uploaded.url,
          mediaType: isVideo ? 'video' : 'photo',
          caption,
          location,
        });
      }

      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
      });

      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Yükleme başarısız oldu.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg max-h-[90vh] flex flex-col rounded-3xl bg-[#11141B] border border-white/10 text-white shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/10 bg-[#141822]">
          <h3 className="font-bold text-base flex items-center gap-2">
            <span>Yeni Paylaşım</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
              SonsuzBiz
            </span>
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-gray-400 hover:text-white hover:bg-white/5"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Post vs Reel switch */}
          <div className="flex p-1 rounded-2xl bg-[#191E28] border border-white/5">
            <button
              type="button"
              onClick={() => {
                setContentType('post');
                setFile(null);
                setPreviewUrl(null);
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                contentType === 'post'
                  ? 'bg-[#3478F6] text-white shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Hatıra Akışı (Foto &amp; Video)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setContentType('reel');
                setFile(null);
                setPreviewUrl(null);
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                contentType === 'reel'
                  ? 'bg-gradient-to-r from-rose-500 to-purple-600 text-white shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Film className="w-3.5 h-3.5" />
              <span>Reels (Dikey Video)</span>
            </button>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Media File Picker Area */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelect}
            accept={contentType === 'reel' ? 'video/*' : 'image/*,video/*'}
            className="hidden"
          />

          {!previewUrl ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-gray-700 hover:border-[#3478F6] rounded-2xl p-8 text-center cursor-pointer transition-all bg-[#191E28]/40 hover:bg-[#191E28]"
            >
              <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mx-auto mb-3 text-[#3478F6]">
                <Upload className="w-6 h-6" />
              </div>
              <h4 className="font-semibold text-sm mb-1">
                {contentType === 'reel' ? 'Dikey Video Seç' : 'Fotoğraf veya Video Seç'}
              </h4>
              <p className="text-xs text-gray-500">
                Galeriden seçim yapmak için tıklayın
              </p>
            </div>
          ) : (
            <div className="relative rounded-2xl overflow-hidden bg-black max-h-64 flex items-center justify-center border border-white/10">
              {file?.type.startsWith('video') ? (
                <video src={previewUrl} controls className="max-h-64 w-full object-contain" />
              ) : (
                <img src={previewUrl} alt="Önizleme" className="max-h-64 w-full object-contain" />
              )}
              <button
                type="button"
                onClick={() => {
                  setFile(null);
                  setPreviewUrl(null);
                }}
                className="absolute top-2 right-2 p-1.5 rounded-full bg-black/60 text-white hover:bg-black"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Caption Input */}
          <div>
            <label className="block text-xs font-semibold text-gray-300 mb-1.5">
              Açıklama / Mesaj
            </label>
            <textarea
              rows={3}
              value={caption}
              onChange={e => setCaption(e.target.value)}
              placeholder="Aşkına güzel bir not bırak..."
              className="w-full px-4 py-2.5 rounded-xl bg-[#191E28] border border-white/10 text-white text-xs placeholder-gray-500 focus:outline-none focus:border-[#3478F6] resize-none"
            />
          </div>

          {/* Location for Posts */}
          {contentType === 'post' && (
            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-1.5 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-rose-400" />
                <span>Konum (İsteğe bağlı)</span>
              </label>
              <input
                type="text"
                value={location}
                onChange={e => setLocation(e.target.value)}
                placeholder="Örn: Boğaz Kenarı, Paris, Evimiz..."
                className="w-full px-4 py-2 rounded-xl bg-[#191E28] border border-white/10 text-white text-xs placeholder-gray-500 focus:outline-none focus:border-[#3478F6]"
              />
            </div>
          )}

          {/* Sound Title for Reels */}
          {contentType === 'reel' && (
            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-1.5 flex items-center gap-1">
                <Music className="w-3.5 h-3.5 text-purple-400" />
                <span>Şarkı / Ses Başlığı</span>
              </label>
              <input
                type="text"
                value={soundTitle}
                onChange={e => setSoundTitle(e.target.value)}
                placeholder="Örn: Bizim Şarkımız - Sezen Aksu"
                className="w-full px-4 py-2 rounded-xl bg-[#191E28] border border-white/10 text-white text-xs placeholder-gray-500 focus:outline-none focus:border-[#3478F6]"
              />
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-white/10 bg-[#141822] flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-gray-400 hover:text-white"
          >
            İptal
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!file || uploading}
            className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#3478F6] hover:bg-blue-600 disabled:opacity-40 text-white shadow-[0_0_15px_rgba(52,120,246,0.4)] active:scale-95 transition-all flex items-center gap-2"
          >
            {uploading ? (
              <>
                <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Yükleniyor...</span>
              </>
            ) : (
              <>
                <CheckCircle className="w-4 h-4" />
                <span>Paylaş</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
