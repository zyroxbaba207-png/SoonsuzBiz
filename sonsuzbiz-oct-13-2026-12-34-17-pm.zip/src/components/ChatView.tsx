import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Image as ImageIcon,
  Smile,
  MoreVertical,
  Check,
  CheckCheck,
  Trash2,
  Palette,
  Heart,
  X,
  FileVideo
} from 'lucide-react';
import { api } from '../api/client';
import { Message, User } from '../types';

interface ChatViewProps {
  currentUser: User;
  partner: User | null;
  onOpenMediaLightbox: (url: string, type: 'photo' | 'video') => void;
  onUpdateCurrentUser: (user: User) => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  currentUser,
  partner,
  onOpenMediaLightbox,
  onUpdateCurrentUser,
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [partnerTyping, setPartnerTyping] = useState(false);
  const [partnerOnline, setPartnerOnline] = useState(false);
  const [partnerLastSeen, setPartnerLastSeen] = useState<number | null>(null);

  // Background selector modal
  const [showBgModal, setShowBgModal] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [activeReactionMenuMsgId, setActiveReactionMenuMsgId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const typingTimeoutRef = useRef<any>(null);

  // Scroll to bottom helper
  const scrollToBottom = (smooth = true) => {
    messagesEndRef.current?.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto' });
  };

  // Poll messages every 1.5s
  useEffect(() => {
    let mounted = true;

    const fetchMessages = async () => {
      try {
        const res = await api.getMessages();
        if (mounted) {
          setMessages(res.messages);
          setPartnerTyping(res.isPartnerTyping);
          setPartnerOnline(res.isPartnerOnline);
          setPartnerLastSeen(res.partnerLastSeen);
        }
      } catch (err) {
        // quiet error on background poll
      }
    };

    fetchMessages();
    const interval = setInterval(fetchMessages, 1500);

    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  // Scroll down on first load or when new message count changes
  useEffect(() => {
    scrollToBottom(false);
  }, [messages.length]);

  // Handle typing ping to backend
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputText(e.target.value);
    if (!isTyping) {
      setIsTyping(true);
      api.pingTyping();
    }
    clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
    }, 2000);
  };

  // Send text message
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    const textToSend = inputText.trim();
    setInputText('');
    setIsTyping(false);

    try {
      const res = await api.sendMessage({ text: textToSend });
      setMessages(prev => [...prev, res.message]);
      scrollToBottom();
    } catch (err: any) {
      alert(err.message || 'Mesaj gönderilemedi.');
    }
  };

  // Send media file in chat
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingMedia(true);
    try {
      const isVideo = file.type.startsWith('video');
      const uploaded = await api.uploadFile(file);
      const res = await api.sendMessage({
        mediaUrl: uploaded.url,
        mediaType: isVideo ? 'video' : 'photo',
        text: '',
      });
      setMessages(prev => [...prev, res.message]);
      scrollToBottom();
    } catch (err: any) {
      alert(err.message || 'Dosya yüklenirken hata oluştu.');
    } finally {
      setUploadingMedia(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Delete message
  const handleDeleteMessage = async (id: string) => {
    if (!confirm('Bu mesajı silmek istiyor musunuz?')) return;
    try {
      await api.deleteMessage(id);
      setMessages(prev => prev.filter(m => m.id !== id));
    } catch (err: any) {
      alert(err.message || 'Mesaj silinemedi.');
    }
  };

  // Add Reaction
  const handleReaction = async (msgId: string, emoji: string) => {
    try {
      const res = await api.toggleReaction(msgId, emoji);
      setMessages(prev =>
        prev.map(m => (m.id === msgId ? { ...m, reactions: res.reactions } : m))
      );
      setActiveReactionMenuMsgId(null);
    } catch (err) {
      // quiet error
    }
  };

  // Change Chat Background
  const handleChangeBg = async (bg: string) => {
    try {
      const res = await api.updateProfile({ chatBackground: bg });
      onUpdateCurrentUser(res.user);
      setShowBgModal(false);
    } catch (err: any) {
      alert(err.message || 'Arka plan güncellenemedi.');
    }
  };

  // Custom chat background image upload
  const handleCustomBgUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const uploaded = await api.uploadFile(file);
      const res = await api.updateProfile({ chatBackground: uploaded.url });
      onUpdateCurrentUser(res.user);
      setShowBgModal(false);
    } catch (err: any) {
      alert(err.message || 'Arka plan fotoğrafı yüklenemedi.');
    }
  };

  // Get background CSS class or style
  const getBackgroundStyle = () => {
    const bg = currentUser.chatBackground || 'starry';
    if (bg.startsWith('/uploads') || bg.startsWith('http')) {
      return {
        backgroundImage: `linear-gradient(rgba(8,9,13,0.7), rgba(8,9,13,0.7)), url(${bg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      };
    }
    return {};
  };

  const getBackgroundClass = () => {
    const bg = currentUser.chatBackground || 'starry';
    if (bg === 'black') return 'bg-black';
    if (bg === 'deepblue') return 'bg-deepblue';
    if (bg === 'night') return 'bg-night';
    if (bg === 'hearts') return 'bg-hearts';
    if (bg === 'starry') return 'bg-starry';
    return 'bg-[#08090D]';
  };

  return (
    <div
      className={`relative flex flex-col h-[calc(100vh-5rem)] max-w-4xl mx-auto rounded-3xl overflow-hidden border border-white/10 shadow-2xl transition-all ${getBackgroundClass()}`}
      style={getBackgroundStyle()}
    >
      {/* Chat Header */}
      <div className="flex items-center justify-between px-5 py-3.5 bg-[#11141B]/90 backdrop-blur-xl border-b border-white/10 z-20">
        <div className="flex items-center gap-3">
          <div className="relative">
            {partner?.avatar ? (
              <img
                src={partner.avatar}
                alt={partner.displayName}
                className="w-11 h-11 rounded-full object-cover ring-2 ring-[#3478F6]/40 shadow-md"
              />
            ) : (
              <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-[#3478F6] to-rose-500 flex items-center justify-center font-bold text-white text-lg">
                {partner ? partner.displayName.charAt(0).toUpperCase() : '❤️'}
              </div>
            )}
            {/* Status indicator badge */}
            <span
              className={`absolute bottom-0 right-0 w-3 h-3 rounded-full ring-2 ring-[#11141B] ${
                partnerOnline ? 'bg-emerald-500 animate-pulse' : 'bg-gray-500'
              }`}
            />
          </div>

          <div>
            <h2 className="text-sm sm:text-base font-bold text-white flex items-center gap-1.5">
              <span>{partner ? partner.displayName : 'Sevgilim Bekleniyor...'}</span>
              <Heart className="w-4 h-4 text-rose-500 fill-rose-500/80" />
            </h2>
            <p className="text-xs text-gray-400">
              {partnerTyping ? (
                <span className="text-[#3478F6] font-semibold animate-pulse">
                  Yazıyor...
                </span>
              ) : partnerOnline ? (
                <span className="text-emerald-400 font-medium">Çevrimiçi</span>
              ) : partnerLastSeen ? (
                <span>
                  Son görülme:{' '}
                  {new Date(partnerLastSeen).toLocaleTimeString('tr-TR', {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              ) : (
                <span>Henüz katılmadı</span>
              )}
            </p>
          </div>
        </div>

        {/* Header Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowBgModal(true)}
            className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Sohbet Arka Planını Değiştir"
          >
            <Palette className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5 z-10">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-gray-400">
            <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mb-3">
              <Heart className="w-8 h-8 text-rose-500 animate-bounce" />
            </div>
            <h3 className="font-bold text-lg text-white mb-1">
              Burası Sadece İkinize Özel
            </h3>
            <p className="text-xs max-w-xs text-gray-400 leading-relaxed">
              Tüm mesajlarınız, fotoğraflarınız ve videolarınız yalnızca ikiniz arasında tamamen gizli ve güvenlidir.
            </p>
          </div>
        ) : (
          messages.map(msg => {
            const isMe = msg.senderId === currentUser.id;
            return (
              <div
                key={msg.id}
                className={`relative flex flex-col group ${isMe ? 'items-end' : 'items-start'}`}
              >
                {/* Message Bubble */}
                <div
                  className={`relative max-w-[82%] sm:max-w-[70%] rounded-2xl px-4 py-2.5 shadow-md backdrop-blur-md text-sm leading-relaxed transition-all ${
                    isMe
                      ? 'bg-gradient-to-r from-[#3478F6] to-[#2563EB] text-white rounded-tr-none'
                      : 'bg-[#191E28]/95 text-gray-100 rounded-tl-none border border-white/5'
                  }`}
                >
                  {/* Photo or Video Media Attachment */}
                  {msg.mediaUrl && (
                    <div className="mb-2 rounded-xl overflow-hidden cursor-pointer max-w-sm">
                      {msg.mediaType === 'video' ? (
                        <video
                          src={msg.mediaUrl}
                          controls
                          className="w-full max-h-72 object-cover rounded-xl"
                        />
                      ) : (
                        <img
                          src={msg.mediaUrl}
                          alt="Fotoğraf"
                          onClick={() => onOpenMediaLightbox(msg.mediaUrl!, 'photo')}
                          className="w-full max-h-72 object-cover rounded-xl hover:opacity-95 transition-opacity"
                        />
                      )}
                    </div>
                  )}

                  {/* Text content */}
                  {msg.text && <p className="whitespace-pre-wrap break-words">{msg.text}</p>}

                  {/* Metadata: Time and Status */}
                  <div
                    className={`flex items-center justify-end gap-1 mt-1 text-[10px] ${
                      isMe ? 'text-blue-100/80' : 'text-gray-400'
                    }`}
                  >
                    <span>
                      {new Date(msg.timestamp).toLocaleTimeString('tr-TR', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    {isMe && (
                      <span>
                        {msg.status === 'read' ? (
                          <CheckCheck className="w-3.5 h-3.5 text-cyan-300" />
                        ) : msg.status === 'delivered' ? (
                          <CheckCheck className="w-3.5 h-3.5 text-gray-300" />
                        ) : (
                          <Check className="w-3.5 h-3.5 text-gray-300" />
                        )}
                      </span>
                    )}
                  </div>

                  {/* Reactions Display */}
                  {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                    <div className="absolute -bottom-3 right-2 flex items-center gap-1 bg-[#11141B] px-1.5 py-0.5 rounded-full border border-white/10 shadow-sm text-xs">
                      {Object.entries(msg.reactions).map(([emoji, userIds]) => (
                        <span
                          key={emoji}
                          onClick={() => handleReaction(msg.id, emoji)}
                          className="cursor-pointer hover:scale-125 transition-transform"
                        >
                          {emoji} {userIds.length > 1 ? userIds.length : ''}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Message Hover Actions (Delete / React) */}
                <div
                  className={`opacity-0 group-hover:opacity-100 flex items-center gap-1 mt-1 px-1 transition-opacity text-gray-400 text-xs ${
                    isMe ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <button
                    onClick={() =>
                      setActiveReactionMenuMsgId(
                        activeReactionMenuMsgId === msg.id ? null : msg.id
                      )
                    }
                    className="p-1 hover:text-rose-400 hover:bg-white/5 rounded-lg"
                    title="Tepki ver"
                  >
                    <Smile className="w-3.5 h-3.5" />
                  </button>

                  {(isMe || currentUser.role === 'admin') && (
                    <button
                      onClick={() => handleDeleteMessage(msg.id)}
                      className="p-1 hover:text-rose-400 hover:bg-white/5 rounded-lg"
                      title="Mesajı sil"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Quick Emoji Reaction Popup */}
                {activeReactionMenuMsgId === msg.id && (
                  <div className="flex items-center gap-1.5 p-1.5 rounded-full bg-[#11141B] border border-white/20 shadow-xl my-1 z-30">
                    {['❤️', '😍', '😘', '🔥', '✨', '🥺'].map(emoji => (
                      <button
                        key={emoji}
                        onClick={() => handleReaction(msg.id, emoji)}
                        className="text-base hover:scale-125 transition-transform p-1"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input Bar */}
      <div className="p-3 sm:p-4 bg-[#11141B]/95 backdrop-blur-xl border-t border-white/10 z-20">
        <form onSubmit={handleSendMessage} className="flex items-center gap-2">
          {/* File Upload Button */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*,video/*"
            className="hidden"
          />
          <button
            type="button"
            disabled={uploadingMedia}
            onClick={() => fileInputRef.current?.click()}
            className="p-2.5 rounded-full bg-[#191E28] hover:bg-[#232a39] text-gray-300 hover:text-white transition-colors cursor-pointer"
            title="Fotoğraf veya Video Gönder"
          >
            {uploadingMedia ? (
              <span className="w-5 h-5 block border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <ImageIcon className="w-5 h-5 text-[#3478F6]" />
            )}
          </button>

          {/* Quick emoji popover button */}
          <button
            type="button"
            onClick={() => setShowEmojiPicker(!showEmojiPicker)}
            className="p-2.5 rounded-full bg-[#191E28] hover:bg-[#232a39] text-gray-300 hover:text-white transition-colors hidden sm:block"
          >
            <Smile className="w-5 h-5 text-amber-400" />
          </button>

          {/* Text input */}
          <input
            type="text"
            value={inputText}
            onChange={handleInputChange}
            placeholder={
              partner
                ? `${partner.displayName} için bir mesaj yaz...`
                : 'Bir mesaj yazın...'
            }
            className="flex-1 px-4 py-3 rounded-full bg-[#191E28] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-[#3478F6] focus:ring-1 focus:ring-[#3478F6] transition-all"
          />

          {/* Send Button */}
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="p-3 rounded-full bg-[#3478F6] hover:bg-blue-600 disabled:opacity-40 disabled:cursor-not-allowed text-white shadow-[0_0_15px_rgba(52,120,246,0.4)] active:scale-95 transition-all"
            title="Gönder"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>

        {/* Emoji picker row */}
        {showEmojiPicker && (
          <div className="flex items-center gap-2 pt-2 px-2 overflow-x-auto no-scrollbar">
            {['❤️', '😍', '😘', '🌹', '💕', '🥰', '💍', '✨', '🔥', '🤍', '💖'].map(emoji => (
              <button
                key={emoji}
                type="button"
                onClick={() => {
                  setInputText(prev => prev + emoji);
                  setShowEmojiPicker(false);
                }}
                className="text-xl hover:scale-125 transition-transform p-1"
              >
                {emoji}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Chat Background Customizer Modal */}
      {showBgModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="max-w-md w-full p-6 rounded-3xl bg-[#11141B] border border-white/10 text-white shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Palette className="w-5 h-5 text-[#3478F6]" />
                <h3 className="font-bold text-base">Sohbet Arka Planı</h3>
              </div>
              <button
                onClick={() => setShowBgModal(false)}
                className="p-1 rounded-lg text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-gray-400 mb-4">
              Sohbet görünümünüze özel arka plan seçin. Seçtiğiniz arka plan yalnızca sizin hesabınız için kalıcı olarak saklanır.
            </p>

            <div className="grid grid-cols-2 gap-3 mb-5">
              {[
                { id: 'starry', label: 'Yıldızlı Gökyüzü', bg: 'bg-starry' },
                { id: 'deepblue', label: 'Koyu Mavi', bg: 'bg-deepblue' },
                { id: 'night', label: 'Gece Manzarası', bg: 'bg-night' },
                { id: 'hearts', label: 'Kalp Desenleri', bg: 'bg-hearts' },
                { id: 'black', label: 'Sade Siyah', bg: 'bg-black' },
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => handleChangeBg(item.id)}
                  className={`p-4 rounded-2xl border text-center font-semibold text-xs transition-all ${item.bg} ${
                    currentUser.chatBackground === item.id
                      ? 'border-[#3478F6] ring-2 ring-[#3478F6]'
                      : 'border-white/10 hover:border-white/30'
                  }`}
                >
                  <span className="text-white drop-shadow-md">{item.label}</span>
                </button>
              ))}
            </div>

            {/* Custom photo upload */}
            <div className="pt-3 border-t border-white/10">
              <label className="block text-xs font-semibold text-gray-300 mb-2">
                Galeriden Kendi Fotoğrafını Yükle:
              </label>
              <label className="flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-xl border border-dashed border-gray-600 hover:border-[#3478F6] cursor-pointer text-xs font-medium text-gray-300 hover:text-white transition-all bg-[#191E28]">
                <ImageIcon className="w-4 h-4 text-[#3478F6]" />
                <span>Fotoğraf Seç ve Arka Plan Yap</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleCustomBgUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
