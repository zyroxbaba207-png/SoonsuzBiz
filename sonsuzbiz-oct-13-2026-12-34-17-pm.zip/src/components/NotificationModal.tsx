import React from 'react';
import { X, Bell, Check, Copy, CheckCheck, KeyRound, Heart, MessageCircle } from 'lucide-react';
import { AppNotification } from '../types';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: AppNotification[];
  onMarkRead: (id: string) => void;
  onMarkAllRead: () => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkRead,
  onMarkAllRead,
}) => {
  const [copiedCode, setCopiedCode] = React.useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg max-h-[85vh] flex flex-col rounded-3xl bg-[#11141B] border border-white/10 shadow-2xl text-white overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/10 bg-[#141822]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#3478F6]/20 text-[#3478F6]">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base">Bildirim Kutusu</h2>
              <p className="text-xs text-gray-400">
                {notifications.filter(n => !n.read).length} okunmamış bildirim
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {notifications.some(n => !n.read) && (
              <button
                onClick={onMarkAllRead}
                className="text-xs text-[#3478F6] hover:underline flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-white/5"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                Tümünü Okundu Say
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-white/5"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notification list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {notifications.length === 0 ? (
            <div className="py-12 text-center text-gray-500">
              <Bell className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-sm">Henüz bir bildiriminiz yok.</p>
            </div>
          ) : (
            notifications.map(n => {
              const isInvite = n.type === 'invite_code' || n.type === 'invite_request';
              const inviteCode = n.metadata?.code;

              return (
                <div
                  key={n.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    !n.read
                      ? 'bg-[#191E28] border-[#3478F6]/40 shadow-sm'
                      : 'bg-[#141822]/60 border-white/5 opacity-80'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-xl shrink-0 mt-0.5 ${
                        isInvite
                          ? 'bg-amber-500/20 text-amber-400'
                          : n.type === 'new_message'
                          ? 'bg-blue-500/20 text-blue-400'
                          : 'bg-rose-500/20 text-rose-400'
                      }`}>
                        {isInvite ? (
                          <KeyRound className="w-4 h-4" />
                        ) : n.type === 'new_message' ? (
                          <MessageCircle className="w-4 h-4" />
                        ) : (
                          <Heart className="w-4 h-4" />
                        )}
                      </div>
                      <div>
                        <h4 className="text-xs sm:text-sm font-bold text-white mb-1">
                          {n.title}
                        </h4>
                        <p className="text-xs text-gray-300 leading-relaxed mb-2">
                          {n.message}
                        </p>
                        <span className="text-[10px] text-gray-500">
                          {new Date(n.createdAt).toLocaleTimeString('tr-TR', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                    </div>

                    {!n.read && (
                      <button
                        onClick={() => onMarkRead(n.id)}
                        title="Okundu olarak işaretle"
                        className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  {/* If this notification contains an invite code, provide 1-click copy */}
                  {inviteCode && (
                    <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between bg-black/30 p-2.5 rounded-xl">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-400">Davet Kodu:</span>
                        <span className="text-sm font-mono font-bold text-amber-300 tracking-wider">
                          {inviteCode}
                        </span>
                      </div>
                      <button
                        onClick={() => handleCopy(inviteCode)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#3478F6] hover:bg-blue-600 text-white text-xs font-semibold shadow-sm active:scale-95 transition-all"
                      >
                        {copiedCode === inviteCode ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-300" />
                            <span>Kopyalandı!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Kopyala</span>
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
