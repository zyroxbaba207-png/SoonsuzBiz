import React, { useState, useEffect } from 'react';
import { Lock, User as UserIcon, Heart, Send, ShieldCheck, KeyRound, Sparkles, AlertCircle, Info, Clock } from 'lucide-react';
import confetti from 'canvas-confetti';
import { api } from '../api/client';
import { AuthStatus, User } from '../types';

interface AuthModalProps {
  authStatus: AuthStatus;
  onSuccess: (user: User) => void;
  onRefreshStatus: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  authStatus,
  onSuccess,
  onRefreshStatus,
}) => {
  // If 0 users in system: default to register (Admin setup). If users exist: default to login.
  const [mode, setMode] = useState<'login' | 'register'>(
    authStatus.allowsFirstAdminRegister ? 'register' : 'login'
  );

  // Form states
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [inviteCode, setInviteCode] = useState('');

  // UI status
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Rate limiting countdown state for invite code button (5 minutes)
  const [cooldown, setCooldown] = useState<number>(authStatus.rateLimitRemainingSeconds || 0);
  const [isRequestingCode, setIsRequestingCode] = useState(false);
  const [showForgotModal, setShowForgotModal] = useState(false);

  // Countdown timer effect
  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => {
      setCooldown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  // Format cooldown mm:ss
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  // Handle Requesting Invite Code from Admin
  const handleRequestInviteCode = async () => {
    if (cooldown > 0) return;
    setIsRequestingCode(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const res = await api.requestInviteCode();
      setSuccessMsg(res.message);
      setCooldown(res.cooldownSeconds || 300);
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch (err: any) {
      setError(err.message || 'Davet kodu isteği gönderilemedi.');
    } finally {
      setIsRequestingCode(false);
    }
  };

  // Handle Login or Register submit
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      if (mode === 'login') {
        const res = await api.login({ username, password });
        confetti({
          particleCount: 70,
          spread: 70,
          origin: { y: 0.6 },
        });
        onSuccess(res.user);
      } else {
        // Register mode
        if (authStatus.allowsFirstAdminRegister) {
          // First user = Admin!
          const res = await api.registerAdmin({
            username,
            displayName,
            password,
          });
          confetti({
            particleCount: 100,
            spread: 90,
            origin: { y: 0.6 },
          });
          onSuccess(res.user);
        } else {
          // Second user = Partner (Needs Invite Code)
          const res = await api.registerPartner({
            username,
            displayName,
            password,
            inviteCode,
          });
          confetti({
            particleCount: 100,
            spread: 90,
            origin: { y: 0.6 },
          });
          onSuccess(res.user);
        }
      }
    } catch (err: any) {
      setError(err.message || 'İşlem başarısız oldu.');
    } finally {
      setLoading(false);
      onRefreshStatus();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#08090D]/90 backdrop-blur-xl overflow-y-auto">
      <div className="relative w-full max-w-md my-8 p-6 sm:p-8 rounded-3xl bg-[#11141B] border border-white/10 shadow-[0_20px_60px_rgba(0,0,0,0.8),0_0_30px_rgba(52,120,246,0.15)] text-white">
        
        {/* Header / Logo */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#3478F6] via-indigo-600 to-rose-500 shadow-[0_0_30px_rgba(52,120,246,0.4)] mb-3">
            <Heart className="w-8 h-8 text-white fill-white/30 animate-pulse" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight bg-gradient-to-r from-white via-blue-100 to-rose-200 bg-clip-text text-transparent">
            SonsuzBiz
          </h1>
          <p className="text-xs sm:text-sm text-gray-400 mt-1">
            Yalnızca iki kişiye özel aşk alanı ve mesajlaşma
          </p>
        </div>

        {/* First user admin badge if no users exist */}
        {authStatus.allowsFirstAdminRegister && (
          <div className="mb-5 p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <strong className="block font-semibold text-amber-300">İlk Kurulum &amp; Yönetici Hesabı</strong>
              Sistemde henüz kullanıcı yok. İlk kayıt olan kişi otomatik olarak <span className="underline">Kurucu ve Yönetici</span> kabul edilir.
            </div>
          </div>
        )}

        {/* Tab switchers if users exist and not fully full */}
        {!authStatus.allowsFirstAdminRegister && (
          <div className="flex p-1 mb-6 rounded-2xl bg-[#191E28] border border-white/5">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError(null);
                setSuccessMsg(null);
              }}
              className={`flex-1 py-2 text-xs sm:text-sm font-semibold rounded-xl transition-all ${
                mode === 'login'
                  ? 'bg-[#3478F6] text-white shadow-[0_0_15px_rgba(52,120,246,0.3)]'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Giriş Yap
            </button>
            <button
              type="button"
              onClick={() => {
                if (authStatus.isCoupleComplete) {
                  setError('Sistemde 2 kişilik çift kotası dolmuştur. Yeni kayıt yapılamaz.');
                  return;
                }
                setMode('register');
                setError(null);
                setSuccessMsg(null);
              }}
              className={`flex-1 py-2 text-xs sm:text-sm font-semibold rounded-xl transition-all ${
                mode === 'register'
                  ? 'bg-[#3478F6] text-white shadow-[0_0_15px_rgba(52,120,246,0.3)]'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Kayıt Ol (Sevgilim)
            </button>
          </div>
        )}

        {/* Special 2-user lock alert if someone tries to register when quota is full */}
        {mode === 'register' && authStatus.isCoupleComplete && (
          <div className="mb-5 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-rose-400 shrink-0" />
            <div>
              <strong className="block font-bold">Kontenjan Dolu</strong>
              SonsuzBiz 2 kişilik özel çift alanıdır. Her iki hesap da kurulmuştur.
            </div>
          </div>
        )}

        {/* Request Invite Code Button for Partner Registration */}
        {mode === 'register' && !authStatus.allowsFirstAdminRegister && !authStatus.isCoupleComplete && (
          <div className="mb-5 p-4 rounded-2xl bg-gradient-to-b from-[#191E28] to-[#141822] border border-[#3478F6]/30 shadow-inner">
            <div className="flex items-center gap-2 mb-2">
              <KeyRound className="w-4 h-4 text-[#3478F6]" />
              <span className="text-xs font-bold text-gray-200">Davet Kodu İsteği</span>
            </div>
            <p className="text-xs text-gray-400 mb-3 leading-relaxed">
              Kayıt olmak için sevgilinizin davet kodu gerekir. Aşağıdaki butona bastığınızda sevgilinizin (yöneticinin) bildirim kutusuna anında yeni bir davet kodu iletilir.
            </p>
            
            <button
              type="button"
              onClick={handleRequestInviteCode}
              disabled={isRequestingCode || cooldown > 0}
              className={`w-full py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                cooldown > 0
                  ? 'bg-gray-800 text-gray-400 border border-gray-700 cursor-not-allowed'
                  : 'bg-gradient-to-r from-[#3478F6] to-indigo-600 hover:from-blue-600 hover:to-indigo-500 text-white shadow-[0_0_20px_rgba(52,120,246,0.3)] active:scale-95'
              }`}
            >
              {isRequestingCode ? (
                <span>Davet Kodu Gönderiliyor...</span>
              ) : cooldown > 0 ? (
                <>
                  <Clock className="w-4 h-4 text-amber-400 animate-spin" />
                  <span>Yeniden İsteme Süresi: {formatTime(cooldown)}</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 text-white" />
                  <span>Yöneticiye Yeni Davet Kodu Gönder</span>
                </>
              )}
            </button>
            <span className="block text-[11px] text-gray-500 text-center mt-1.5">
              (Güvenlik gereği her 5 dakikada bir kod gönderilebilir)
            </span>
          </div>
        )}

        {/* Error and Success Notices */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span className="leading-relaxed">{successMsg}</span>
          </div>
        )}

        {/* Auth Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Display Name (Only during registration) */}
          {mode === 'register' && (
            <div>
              <label className="block text-xs font-medium text-gray-300 mb-1.5">
                {authStatus.allowsFirstAdminRegister ? 'Adınız / Hitap Şekliniz' : 'Sevgilinizin Size Hitabı (Örn: Aşkım, Bitanem)'}
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={displayName}
                  onChange={e => setDisplayName(e.target.value)}
                  placeholder={authStatus.allowsFirstAdminRegister ? 'Örn: Can' : 'Örn: Sevgilim, Hayatım'}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#191E28] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-[#3478F6] focus:ring-1 focus:ring-[#3478F6] transition-all"
                />
              </div>
            </div>
          )}

          {/* Username */}
          <div>
            <label className="block text-xs font-medium text-gray-300 mb-1.5">
              Kullanıcı Adı
            </label>
            <div className="relative flex items-center">
              <UserIcon className="w-4 h-4 text-gray-500 absolute left-3.5" />
              <input
                type="text"
                required
                value={username}
                onChange={e => setUsername(e.target.value)}
                placeholder="kullaniciadi"
                autoCapitalize="none"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#191E28] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-[#3478F6] focus:ring-1 focus:ring-[#3478F6] transition-all"
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-gray-300">
                Şifre
              </label>
              {mode === 'login' && (
                <button
                  type="button"
                  onClick={() => setShowForgotModal(true)}
                  className="text-[11px] text-[#3478F6] hover:underline"
                >
                  Şifremi unuttum?
                </button>
              )}
            </div>
            <div className="relative flex items-center">
              <Lock className="w-4 h-4 text-gray-500 absolute left-3.5" />
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#191E28] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-[#3478F6] focus:ring-1 focus:ring-[#3478F6] transition-all"
              />
            </div>
          </div>

          {/* Invite Code field (Only when registering partner) */}
          {mode === 'register' && !authStatus.allowsFirstAdminRegister && (
            <div>
              <label className="block text-xs font-medium text-gray-300 mb-1.5">
                Davet Kodu (Tek Kullanımlık)
              </label>
              <div className="relative flex items-center">
                <KeyRound className="w-4 h-4 text-gray-500 absolute left-3.5" />
                <input
                  type="text"
                  required
                  value={inviteCode}
                  onChange={e => setInviteCode(e.target.value.toUpperCase())}
                  placeholder="Örn: BIZ-1234"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#191E28] border border-white/10 text-white text-sm uppercase tracking-wider placeholder-gray-500 focus:outline-none focus:border-[#3478F6] focus:ring-1 focus:ring-[#3478F6] transition-all"
                />
              </div>
              <span className="text-[11px] text-gray-400 mt-1 block">
                Yukarıdaki butona bastıysanız, kodu sevgilinizin bildirim kutusundan öğreniniz.
              </span>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading || (mode === 'register' && authStatus.isCoupleComplete)}
            className="w-full mt-2 py-3 px-4 rounded-xl font-bold text-sm bg-gradient-to-r from-[#3478F6] via-blue-600 to-indigo-600 text-white shadow-[0_4px_25px_rgba(52,120,246,0.4)] hover:shadow-[0_6px_30px_rgba(52,120,246,0.6)] active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Lütfen bekleyin...
              </span>
            ) : mode === 'login' ? (
              'Giriş Yap'
            ) : authStatus.allowsFirstAdminRegister ? (
              'Yönetici Olarak Başla'
            ) : (
              'Kaydı Tamamla & SonsuzBiz\'e Katıl'
            )}
          </button>
        </form>

        {/* Security and privacy footer note */}
        <div className="mt-6 pt-4 border-t border-white/5 text-center text-[11px] text-gray-500 flex items-center justify-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Şifreler PBKDF2 ile şifrelenir. Google veya 3. parti giriş yoktur.</span>
        </div>
      </div>

      {/* Forgot Password Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="max-w-md w-full p-6 rounded-3xl bg-[#11141B] border border-white/10 text-white shadow-2xl">
            <div className="flex items-center gap-3 mb-3 text-amber-400">
              <Info className="w-6 h-6" />
              <h3 className="font-bold text-lg text-white">Şifremi Unuttum</h3>
            </div>
            <p className="text-xs sm:text-sm text-gray-300 leading-relaxed mb-4">
              SonsuzBiz güvenli ve e-posta bağımsız bir yapıda tasarlanmıştır. Şifrenizi unuttuysanız:
            </p>
            <ul className="text-xs sm:text-sm text-gray-400 space-y-2 mb-6 list-disc list-inside">
              <li>Eğer <strong>sevgili hesabıysanız</strong>, yöneticiniz (kurucu sevgiliniz) kendi <strong>Yönetici Paneli</strong> üzerinden şifrenizi tek tuşla anında yeni bir şifreye sıfırlayabilir.</li>
              <li>Eğer <strong>yönetici hesabıysanız</strong> ve şifrenizi unuttuysanız, sunucu yöneticisi veritabanını güvenle sıfırlayabilir.</li>
            </ul>
            <button
              onClick={() => setShowForgotModal(false)}
              className="w-full py-2.5 rounded-xl bg-[#3478F6] text-white font-semibold text-sm hover:bg-blue-600 transition-colors"
            >
              Anladım, Kapat
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
