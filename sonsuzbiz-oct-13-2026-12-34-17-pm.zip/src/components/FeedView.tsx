import React, { useState, useEffect } from 'react';
import {
  Heart,
  MessageCircle,
  Share2,
  Trash2,
  Plus,
  Calendar,
  Sparkles,
  Send,
  MapPin,
  Clock,
  Film,
  Image as ImageIcon
} from 'lucide-react';
import { api } from '../api/client';
import { Post, User } from '../types';

interface FeedViewProps {
  currentUser: User;
  anniversaryDate: string;
  coupleTitle: string;
  onOpenUpload: () => void;
  onOpenMediaLightbox: (url: string, type: 'photo' | 'video') => void;
}

export const FeedView: React.FC<FeedViewProps> = ({
  currentUser,
  anniversaryDate,
  coupleTitle,
  onOpenUpload,
  onOpenMediaLightbox,
}) => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [filter, setFilter] = useState<'all' | 'photo' | 'video'>('all');
  const [loading, setLoading] = useState(true);
  const [activeCommentPostId, setActiveCommentPostId] = useState<string | null>(null);
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});

  // Anniversary elapsed calculation
  const [togetherTime, setTogetherTime] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  }>({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const updateCounter = () => {
      const start = new Date(anniversaryDate).getTime();
      const now = Date.now();
      const diff = Math.max(0, now - start);

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / (1000 * 60)) % 60);
      const seconds = Math.floor((diff / 1000) % 60);

      setTogetherTime({ days, hours, minutes, seconds });
    };

    updateCounter();
    const interval = setInterval(updateCounter, 1000);
    return () => clearInterval(interval);
  }, [anniversaryDate]);

  const fetchPosts = async () => {
    try {
      setLoading(true);
      const res = await api.getPosts();
      setPosts(res.posts);
    } catch (err) {
      console.error('Posts fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  const handleLike = async (postId: string) => {
    try {
      const res = await api.togglePostLike(postId);
      setPosts(prev =>
        prev.map(p => (p.id === postId ? { ...p, likes: res.likes } : p))
      );
    } catch (err: any) {
      alert(err.message || 'Beğeni başarısız.');
    }
  };

  const handleDelete = async (postId: string) => {
    if (!confirm('Bu anıyı silmek istiyor musunuz?')) return;
    try {
      await api.deletePost(postId);
      setPosts(prev => prev.filter(p => p.id !== postId));
    } catch (err: any) {
      alert(err.message || 'Paylaşım silinemedi.');
    }
  };

  const handleCommentSubmit = async (e: React.FormEvent, postId: string) => {
    e.preventDefault();
    const text = commentInputs[postId]?.trim();
    if (!text) return;

    try {
      const res = await api.addPostComment(postId, text);
      setPosts(prev =>
        prev.map(p =>
          p.id === postId ? { ...p, comments: [...p.comments, res.comment] } : p
        )
      );
      setCommentInputs(prev => ({ ...prev, [postId]: '' }));
    } catch (err: any) {
      alert(err.message || 'Yorum eklenemedi.');
    }
  };

  const filteredPosts = posts.filter(p => {
    if (filter === 'all') return true;
    return p.mediaType === filter;
  });

  return (
    <div className="max-w-xl mx-auto pb-24 px-4 pt-3">
      {/* Couple Anniversary Live Banner */}
      <div className="relative mb-6 p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-[#141824] via-[#11141B] to-[#1e1528] border border-white/10 shadow-2xl overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute top-0 right-0 -mr-10 -mt-10 w-40 h-40 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-10 -mb-10 w-40 h-40 bg-[#3478F6]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-rose-400 text-xs font-bold tracking-wider uppercase mb-1">
              <Sparkles className="w-4 h-4 text-rose-400" />
              <span>{coupleTitle} Aşk Sayacı</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white">
              Birlikte Geçen Zamanımız
            </h2>
          </div>

          {/* Time digits */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            <div className="text-center px-3 py-2 rounded-2xl bg-white/5 border border-white/10 shadow-inner">
              <span className="block text-lg sm:text-xl font-extrabold text-[#3478F6]">
                {togetherTime.days}
              </span>
              <span className="text-[10px] text-gray-400 uppercase font-semibold">Gün</span>
            </div>
            <div className="text-center px-3 py-2 rounded-2xl bg-white/5 border border-white/10 shadow-inner">
              <span className="block text-lg sm:text-xl font-extrabold text-rose-400">
                {togetherTime.hours}
              </span>
              <span className="text-[10px] text-gray-400 uppercase font-semibold">Saat</span>
            </div>
            <div className="text-center px-3 py-2 rounded-2xl bg-white/5 border border-white/10 shadow-inner">
              <span className="block text-lg sm:text-xl font-extrabold text-amber-300">
                {togetherTime.minutes}
              </span>
              <span className="text-[10px] text-gray-400 uppercase font-semibold">Dakika</span>
            </div>
            <div className="text-center px-3 py-2 rounded-2xl bg-white/5 border border-white/10 shadow-inner">
              <span className="block text-lg sm:text-xl font-extrabold text-purple-400">
                {togetherTime.seconds}
              </span>
              <span className="text-[10px] text-gray-400 uppercase font-semibold">Sn</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-[#11141B] border border-white/5">
          <button
            onClick={() => setFilter('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              filter === 'all'
                ? 'bg-[#3478F6] text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Tüm Anılar ({posts.length})
          </button>
          <button
            onClick={() => setFilter('photo')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1 ${
              filter === 'photo'
                ? 'bg-[#3478F6] text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Fotoğraflar</span>
          </button>
          <button
            onClick={() => setFilter('video')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1 ${
              filter === 'video'
                ? 'bg-[#3478F6] text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>Videolar</span>
          </button>
        </div>

        {/* Quick Post Button */}
        <button
          onClick={onOpenUpload}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#191E28] hover:bg-[#232938] text-xs font-semibold text-gray-200 hover:text-white border border-white/10 transition-colors"
        >
          <Plus className="w-3.5 h-3.5 text-[#3478F6]" />
          <span>Paylaş</span>
        </button>
      </div>

      {/* Posts List */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-3 border-[#3478F6] border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filteredPosts.length === 0 ? (
        <div className="text-center py-16 px-4 rounded-3xl bg-[#11141B] border border-white/5">
          <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-3">
            <Heart className="w-8 h-8 text-rose-500/60" />
          </div>
          <h3 className="font-bold text-base text-white mb-1">Henüz Anı Paylaşılmadı</h3>
          <p className="text-xs text-gray-400 max-w-sm mx-auto mb-5">
            İkinizin en güzel fotoğraflarını ve videolarını burada sonsuza dek biriktirin.
          </p>
          <button
            onClick={onOpenUpload}
            className="px-5 py-2.5 rounded-full bg-[#3478F6] text-white text-xs font-bold hover:bg-blue-600 transition-colors inline-flex items-center gap-2 cursor-pointer shadow-lg shadow-blue-500/20"
          >
            <Plus className="w-4 h-4" />
            <span>İlk Anımızı Paylaş</span>
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {filteredPosts.map(post => {
            const isLiked = post.likes.includes(currentUser.id);
            const canDelete = post.authorId === currentUser.id || currentUser.role === 'admin';

            return (
              <article
                key={post.id}
                className="rounded-3xl bg-[#11141B] border border-white/10 shadow-xl overflow-hidden transition-all hover:border-white/20"
              >
                {/* Post Author Bar */}
                <div className="flex items-center justify-between p-4 border-b border-white/5">
                  <div className="flex items-center gap-3">
                    <img
                      src={
                        post.author?.avatar ||
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop'
                      }
                      alt="avatar"
                      className="w-10 h-10 rounded-full object-cover ring-2 ring-white/10"
                    />
                    <div>
                      <h4 className="font-bold text-sm text-white flex items-center gap-1.5">
                        <span>{post.author?.displayName || 'Aşkım'}</span>
                        <span className="text-xs font-normal text-gray-400">
                          @{post.author?.username}
                        </span>
                      </h4>
                      <div className="flex items-center gap-2 text-[11px] text-gray-400">
                        <span>{new Date(post.createdAt).toLocaleDateString('tr-TR')}</span>
                        {post.location && (
                          <span className="flex items-center gap-0.5 text-rose-300">
                            <MapPin className="w-3 h-3" />
                            <span>{post.location}</span>
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {canDelete && (
                    <button
                      onClick={() => handleDelete(post.id)}
                      className="p-2 text-gray-400 hover:text-rose-400 hover:bg-white/5 rounded-xl transition-colors"
                      title="Sil"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Media Container */}
                <div
                  className="relative w-full max-h-[500px] bg-black flex items-center justify-center cursor-pointer overflow-hidden"
                  onClick={() => onOpenMediaLightbox(post.mediaUrl, post.mediaType)}
                >
                  {post.mediaType === 'video' ? (
                    <video
                      src={post.mediaUrl}
                      controls
                      className="w-full max-h-[500px] object-cover"
                    />
                  ) : (
                    <img
                      src={post.mediaUrl}
                      alt="Hatıra"
                      className="w-full max-h-[500px] object-cover hover:scale-105 transition-transform duration-500"
                    />
                  )}
                </div>

                {/* Post Footer & Actions */}
                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-4">
                      {/* Like */}
                      <button
                        onClick={() => handleLike(post.id)}
                        className="flex items-center gap-1.5 text-xs font-semibold group transition-all"
                      >
                        <Heart
                          className={`w-6 h-6 transition-transform group-hover:scale-125 ${
                            isLiked
                              ? 'text-rose-500 fill-rose-500 animate-pulse'
                              : 'text-gray-300'
                          }`}
                        />
                        <span className={isLiked ? 'text-rose-400' : 'text-gray-300'}>
                          {post.likes.length}
                        </span>
                      </button>

                      {/* Comment Toggle */}
                      <button
                        onClick={() =>
                          setActiveCommentPostId(
                            activeCommentPostId === post.id ? null : post.id
                          )
                        }
                        className="flex items-center gap-1.5 text-xs font-semibold text-gray-300 hover:text-white transition-colors"
                      >
                        <MessageCircle className="w-6 h-6" />
                        <span>{post.comments.length}</span>
                      </button>
                    </div>

                    <span className="text-[11px] text-gray-500 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {new Date(post.createdAt).toLocaleTimeString('tr-TR', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>

                  {/* Caption */}
                  {post.caption && (
                    <p className="text-xs sm:text-sm text-gray-200 leading-relaxed mb-3">
                      <strong className="font-semibold text-white mr-2">
                        {post.author?.displayName}:
                      </strong>
                      {post.caption}
                    </p>
                  )}

                  {/* Comments preview / drawer */}
                  {post.comments.length > 0 && (
                    <div className="mt-2 space-y-1.5 pt-2 border-t border-white/5">
                      {post.comments.slice(-3).map(c => (
                        <div key={c.id} className="text-xs text-gray-300">
                          <span className="font-semibold text-blue-300 mr-1.5">
                            {c.userId === currentUser.id ? 'Sen' : 'Sevgilin'}:
                          </span>
                          <span>{c.text}</span>
                        </div>
                      ))}
                      {post.comments.length > 3 && (
                        <button
                          onClick={() => setActiveCommentPostId(post.id)}
                          className="text-[11px] text-gray-400 hover:underline pt-1 block"
                        >
                          Tüm {post.comments.length} yorumu gör...
                        </button>
                      )}
                    </div>
                  )}

                  {/* Add comment field */}
                  <form
                    onSubmit={e => handleCommentSubmit(e, post.id)}
                    className="flex items-center gap-2 mt-3 pt-3 border-t border-white/5"
                  >
                    <input
                      type="text"
                      value={commentInputs[post.id] || ''}
                      onChange={e =>
                        setCommentInputs({ ...commentInputs, [post.id]: e.target.value })
                      }
                      placeholder="Bir yorum veya kalp bırak..."
                      className="flex-1 px-3.5 py-2 rounded-full bg-[#191E28] border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-[#3478F6]"
                    />
                    <button
                      type="submit"
                      disabled={!commentInputs[post.id]?.trim()}
                      className="p-2 rounded-full bg-[#3478F6] text-white disabled:opacity-40"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </form>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
