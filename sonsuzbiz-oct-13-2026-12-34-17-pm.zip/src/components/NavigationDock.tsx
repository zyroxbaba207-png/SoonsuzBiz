import React from 'react';
import { Home, Film, Plus, MessageCircleHeart, User, ShieldAlert } from 'lucide-react';
import { User as UserType } from '../types';

export type TabType = 'feed' | 'reels' | 'chat' | 'profile' | 'admin';

interface NavigationDockProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  onOpenUpload: () => void;
  unreadMessagesCount: number;
  currentUser: UserType | null;
}

export const NavigationDock: React.FC<NavigationDockProps> = ({
  activeTab,
  onTabChange,
  onOpenUpload,
  unreadMessagesCount,
  currentUser,
}) => {
  return (
    <div className="fixed bottom-5 left-0 right-0 z-40 flex justify-center items-center px-4 pointer-events-none">
      <nav
        aria-label="Alt Navigasyon Menüsü"
        className="pointer-events-auto flex items-center gap-1 sm:gap-2 px-3 sm:px-4 py-2.5 rounded-full bg-[#11141B]/85 backdrop-blur-2xl border border-white/10 shadow-[0_12px_40px_rgba(0,0,0,0.7),0_0_20px_rgba(52,120,246,0.15)] transition-all duration-300 hover:border-white/20 max-w-fit"
      >
        {/* 1. Akış / Hatıralar */}
        <button
          onClick={() => onTabChange('feed')}
          className={`relative flex items-center gap-2 px-3.5 py-2 rounded-full transition-all duration-300 group ${
            activeTab === 'feed'
              ? 'bg-[#3478F6] text-white shadow-[0_0_15px_rgba(52,120,246,0.5)] font-semibold'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
          title="Hatıralar Akışı"
        >
          <Home className="w-5 h-5 transition-transform group-hover:scale-110" />
          <span className="text-xs tracking-wide hidden sm:inline">Akış</span>
        </button>

        {/* 2. Reels / Dikey Video */}
        <button
          onClick={() => onTabChange('reels')}
          className={`relative flex items-center gap-2 px-3.5 py-2 rounded-full transition-all duration-300 group ${
            activeTab === 'reels'
              ? 'bg-gradient-to-r from-rose-500 to-purple-600 text-white shadow-[0_0_15px_rgba(244,63,94,0.5)] font-semibold'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
          title="Dikey Video Akışı"
        >
          <Film className="w-5 h-5 transition-transform group-hover:scale-110" />
          <span className="text-xs tracking-wide hidden sm:inline">Reels</span>
        </button>

        {/* 3. Ortada Paylaş Butonu (Pill / Floating Icon) */}
        <button
          onClick={onOpenUpload}
          className="relative mx-1 flex items-center justify-center w-11 h-11 rounded-full bg-gradient-to-br from-[#3478F6] to-rose-500 text-white shadow-[0_4px_20px_rgba(52,120,246,0.4)] transition-all duration-300 hover:scale-110 active:scale-95 group hover:shadow-[0_6px_25px_rgba(244,63,94,0.6)] cursor-pointer"
          title="Fotoğraf veya Video Paylaş"
        >
          <Plus className="w-6 h-6 stroke-[2.5] transition-transform duration-300 group-hover:rotate-90" />
        </button>

        {/* 4. Sohbet (WhatsApp benzeri) */}
        <button
          onClick={() => onTabChange('chat')}
          className={`relative flex items-center gap-2 px-3.5 py-2 rounded-full transition-all duration-300 group ${
            activeTab === 'chat'
              ? 'bg-[#3478F6] text-white shadow-[0_0_15px_rgba(52,120,246,0.5)] font-semibold'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
          title="Özel Sohbet"
        >
          <div className="relative">
            <MessageCircleHeart className="w-5 h-5 transition-transform group-hover:scale-110" />
            {unreadMessagesCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-rose-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-pulse shadow-sm">
                {unreadMessagesCount > 9 ? '9+' : unreadMessagesCount}
              </span>
            )}
          </div>
          <span className="text-xs tracking-wide hidden sm:inline">Sohbet</span>
        </button>

        {/* 5. Profil */}
        <button
          onClick={() => onTabChange('profile')}
          className={`relative flex items-center gap-2 px-3.5 py-2 rounded-full transition-all duration-300 group ${
            activeTab === 'profile'
              ? 'bg-[#3478F6] text-white shadow-[0_0_15px_rgba(52,120,246,0.5)] font-semibold'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
          title="Profil ve Ayarlar"
        >
          {currentUser?.avatar ? (
            <img
              src={currentUser.avatar}
              alt={currentUser.displayName}
              className="w-5 h-5 rounded-full object-cover ring-1 ring-white/20"
            />
          ) : (
            <User className="w-5 h-5 transition-transform group-hover:scale-110" />
          )}
          <span className="text-xs tracking-wide hidden sm:inline">Profil</span>
        </button>

        {/* 6. Admin Panel Sekmesi (Yalnızca Yönetici Görür) */}
        {currentUser?.role === 'admin' && (
          <button
            onClick={() => onTabChange('admin')}
            className={`relative flex items-center gap-2 px-3 py-2 rounded-full transition-all duration-300 group ${
              activeTab === 'admin'
                ? 'bg-amber-500 text-black shadow-[0_0_15px_rgba(245,158,11,0.5)] font-bold'
                : 'text-amber-400 hover:text-amber-300 hover:bg-amber-500/10'
            }`}
            title="Yönetici Paneli (Kurucu)"
          >
            <ShieldAlert className="w-4 h-4 transition-transform group-hover:scale-110" />
            <span className="text-xs tracking-wide hidden md:inline">Yönetici</span>
          </button>
        )}
      </nav>
    </div>
  );
};
