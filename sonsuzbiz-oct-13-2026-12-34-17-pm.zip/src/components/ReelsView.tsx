import React, { useState, useEffect, useRef } from 'react';
import {
  Heart,
  MessageCircle,
  Volume2,
  VolumeX,
  Plus,
  Trash2,
  Music,
  Share2,
  Send,
  X,
  Play
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { api } from '../api/client';
import { Reel, User } from '../types';

interface ReelsViewProps {
  currentUser: User;
  onOpenUploadVideo: () => void;
}

export const ReelsView: React.FC<ReelsViewProps> = ({
  currentUser,
  onOpenUploadVideo,
}) => {
  const [reels, setReels] = useState<Reel[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(true);
  const [activeCommentsReel, setActiveCommentsReel] = useState<Reel | null>(null);
  const [commentText, setCommentText] = useState('');
  const [loading, setLoading] = useState(true);

  // Floating heart burst animation on double tap
  const [floatingHearts, setFloatingHearts] = useState<{ id: number; x: number; y: number }[]>([]);

  const containerRef = useRef<HTMLDivElement>(null);
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([]);

  // Fetch reels
  const fetchReels = async () => {
    try {
      setLoading(true);
      const res = await api.getReels();
      setReels(res.reels);
    } catch (err) {
      console.error('Reels fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReels();
  }, []);

  // Intersection Observer to autoplay active video and pause others
  useEffect(() => {
    videoRefs.current.forEach((video, idx) => {
      if (!video) return;
      if (idx === currentIndex) {
        video.currentTime = 0;
        video.play().catch(() => {
          // Autoplay policy fallback: mute and play
          video.muted = true;
          video.play().catch(() => {});
        });
      } else {
        video.pause();
      }
    });
  }, [currentIndex, reels]);

  // Handle scroll snap detection
  const handleScroll = () => {
    if (!containerRef.current) return;
    const { scrollTop, clientHeight } = containerRef.current;
    const index = Math.round(scrollTop / clientHeight);
    if (index !== currentIndex && index >= 0 && index < reels.length) {
      setCurrentIndex(index);
    }
  };

  // Toggle Like
  const handleLike = async (reelId: string) => {
    try {
      const res = await api.toggleReelLike(reelId);
      setReels(prev =>
        prev.map(r => (r.id === reelId ? { ...r, likes: res.likes } : r))
      );
    } catch (err: any) {
      alert(err.message || 'Beğeni işlemi başarısız.');
    }
  };

  // Double Tap Screen for Like
  const handleDoubleTap = (e: React.MouseEvent, reel: Reel) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const newHeart = { id: Date.now(), x, y };
    setFloatingHearts(prev => [...prev, newHeart]);
    setTimeout(() => {
      setFloatingHearts(prev => prev.filter(h => h.id !== newHeart.id));
    }, 1000);

    if (!reel.likes.includes(currentUser.id)) {
      handleLike(reel.id);
    }
  };

  // Delete Reel
  const handleDeleteReel = async (reelId: string) => {
    if (!confirm('Bu videoyu silmek istediğinize emin misiniz?')) return;
    try {
      await api.deleteReel(reelId);
      setReels(prev => prev.filter(r => r.id !== reelId));
    } catch (err: any) {
      alert(err.message || 'Video silinemedi.');
    }
  };

  // Add Comment
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCommentsReel || !commentText.trim()) return;

    try {
      const res = await api.addReelComment(activeCommentsReel.id, commentText.trim());
      const updatedComments = [...activeCommentsReel.comments, res.comment];
      const updatedReel = { ...activeCommentsReel, comments: updatedComments };

      setActiveCommentsReel(updatedReel);
      setReels(prev => prev.map(r => (r.id === activeCommentsReel.id ? updatedReel : r)));
      setCommentText('');
    } catch (err: any) {
      alert(err.message || 'Yorum eklenemedi.');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-6rem)]">
        <div className="w-8 h-8 border-3 border-[#3478F6] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (reels.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[calc(100vh-6rem)] max-w-md mx-auto text-center p-6 text-white">
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-rose-500 to-purple-600 flex items-center justify-center shadow-[0_0_40px_rgba(244,63,94,0.4)] mb-4">
          <Heart className="w-10 h-10 text-white fill-white/20 animate-pulse" />
        </div>
        <h2 className="text-xl font-bold mb-2">Henüz Reels Videosu Yok</h2>
        <p className="text-sm text-gray-400 mb-6 leading-relaxed">
          TikTok benzeri bu dikey akışta sevgilinizle beraber çektiğiniz özel videoları paylaşın ve kaydırarak izleyin!
        </p>
        <button
          onClick={onOpenUploadVideo}
          className="flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-rose-500 to-purple-600 text-white font-bold text-sm shadow-[0_0_20px_rgba(244,63,94,0.5)] active:scale-95 transition-all cursor-pointer"
        >
          <Plus className="w-5 h-5" />
          <span>İlk Videomuzu Yükle</span>
        </button>
      </div>
    );
  }

  return (
    <div className="relative flex justify-center items-center h-[calc(100vh-5.5rem)] w-full">
      {/* 9:16 Video Container */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="relative w-full max-w-[420px] h-full overflow-y-scroll snap-y snap-mandatory rounded-3xl border border-white/10 shadow-2xl bg-black no-scrollbar"
      >
        {reels.map((reel, idx) => {
          const isLiked = reel.likes.includes(currentUser.id);
          const canDelete = reel.authorId === currentUser.id || currentUser.role === 'admin';

          return (
            <div
              key={reel.id}
              className="relative w-full h-full snap-start snap-always shrink-0 flex items-center justify-center overflow-hidden bg-black select-none"
              onDoubleClick={e => handleDoubleTap(e, reel)}
            >
              {/* Video Element */}
              <video
                ref={el => {
                  videoRefs.current[idx] = el;
                }}
                src={reel.videoUrl}
                loop
                playsInline
                muted={isMuted}
                className="w-full h-full object-cover cursor-pointer"
                onClick={() => {
                  const video = videoRefs.current[idx];
                  if (video) {
                    if (video.paused) video.play();
                    else video.pause();
                  }
                }}
              />

              {/* Top Bar inside Video: Sound Mute & Counter */}
              <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-20">
                <span className="px-3 py-1 rounded-full bg-black/40 backdrop-blur-md text-[11px] font-semibold text-white/80 border border-white/10">
                  {idx + 1} / {reels.length}
                </span>

                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-2.5 rounded-full bg-black/40 backdrop-blur-md text-white border border-white/10 hover:bg-black/60 transition-colors"
                >
                  {isMuted ? (
                    <VolumeX className="w-4 h-4 text-rose-400" />
                  ) : (
                    <Volume2 className="w-4 h-4 text-emerald-400" />
                  )}
                </button>
              </div>

              {/* Floating Hearts from double tap */}
              {floatingHearts.map(h => (
                <div
                  key={h.id}
                  style={{ left: h.x, top: h.y }}
                  className="absolute pointer-events-none -translate-x-1/2 -translate-y-1/2 animate-ping z-30"
                >
                  <Heart className="w-16 h-16 text-rose-500 fill-rose-500 drop-shadow-xl" />
                </div>
              ))}

              {/* Bottom Overlay Info (Caption, Author, Song) */}
              <div className="absolute bottom-16 left-4 right-16 z-20 text-white drop-shadow-lg">
                {/* Author Info */}
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-9 h-9 rounded-full overflow-hidden ring-2 ring-white/40">
                    <img
                      src={
                        reel.author?.avatar ||
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop'
                      }
                      alt="avatar"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm tracking-wide">
                      @{reel.author?.username || 'sevgilim'}
                    </h3>
                    <span className="text-[10px] text-gray-300">
                      {new Date(reel.createdAt).toLocaleDateString('tr-TR')}
                    </span>
                  </div>
                </div>

                {/* Caption */}
                {reel.caption && (
                  <p className="text-xs sm:text-sm text-gray-100 font-medium line-clamp-2 mb-2.5 leading-snug">
                    {reel.caption}
                  </p>
                )}

                {/* Sound ticker */}
                <div className="flex items-center gap-1.5 text-xs text-rose-300 font-medium">
                  <Music className="w-3.5 h-3.5 shrink-0 animate-spin" />
                  <span className="truncate">{reel.soundTitle || 'SonsuzBiz Aşk Şarkısı ❤️'}</span>
                </div>
              </div>

              {/* Right Side Action Column (Likes, Comments, Delete) */}
              <div className="absolute right-3 bottom-16 flex flex-col items-center gap-5 z-20 text-white">
                {/* Like Button */}
                <div className="flex flex-col items-center gap-1">
                  <button
                    onClick={() => handleLike(reel.id)}
                    className="p-3 rounded-full bg-black/40 backdrop-blur-md border border-white/10 hover:scale-110 active:scale-90 transition-all"
                  >
                    <Heart
                      className={`w-6 h-6 ${
                        isLiked
                          ? 'text-rose-500 fill-rose-500 animate-pulse'
                          : 'text-white'
                      }`}
                    />
                  </button>
                  <span className="text-xs font-bold">{reel.likes.length}</span>
                </div>

                {/* Comment Button */}
                <div className="flex flex-col items-center gap-1">
                  <button
                    onClick={() => setActiveCommentsReel(reel)}
                    className="p-3 rounded-full bg-black/40 backdrop-blur-md border border-white/10 hover:scale-110 active:scale-90 transition-all"
                  >
                    <MessageCircle className="w-6 h-6 text-white" />
                  </button>
                  <span className="text-xs font-bold">{reel.comments.length}</span>
                </div>

                {/* Delete Button (If author or admin) */}
                {canDelete && (
                  <button
                    onClick={() => handleDeleteReel(reel.id)}
                    className="p-2.5 rounded-full bg-black/40 backdrop-blur-md border border-white/10 text-gray-300 hover:text-rose-400 hover:bg-black/70 transition-colors"
                    title="Videoyu Sil"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Comments Drawer / Modal */}
      {activeCommentsReel && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md max-h-[70vh] flex flex-col rounded-t-3xl bg-[#11141B] border-t border-white/10 p-4 text-white shadow-2xl animate-slide-up">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="font-bold text-sm">
                Yorumlar ({activeCommentsReel.comments.length})
              </h3>
              <button
                onClick={() => setActiveCommentsReel(null)}
                className="p-1.5 rounded-lg text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Comments List */}
            <div className="flex-1 overflow-y-auto py-3 space-y-3">
              {activeCommentsReel.comments.length === 0 ? (
                <div className="py-8 text-center text-gray-500 text-xs">
                  Henüz yorum yapılmadı. İlk yorumu sen yap! ❤️
                </div>
              ) : (
                activeCommentsReel.comments.map(c => (
                  <div key={c.id} className="p-2.5 rounded-xl bg-[#191E28] text-xs">
                    <div className="flex items-center justify-between text-gray-400 mb-1">
                      <span className="font-semibold text-blue-300">
                        {c.userId === currentUser.id ? 'Sen' : 'Sevgilin'}
                      </span>
                      <span className="text-[10px]">
                        {new Date(c.createdAt).toLocaleTimeString('tr-TR', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <p className="text-gray-200">{c.text}</p>
                  </div>
                ))
              )}
            </div>

            {/* Add Comment Input */}
            <form onSubmit={handleAddComment} className="flex items-center gap-2 pt-2 border-t border-white/10">
              <input
                type="text"
                value={commentText}
                onChange={e => setCommentText(e.target.value)}
                placeholder="Tatlı bir yorum yaz..."
                className="flex-1 px-4 py-2.5 rounded-full bg-[#191E28] border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-[#3478F6]"
              />
              <button
                type="submit"
                disabled={!commentText.trim()}
                className="p-2.5 rounded-full bg-[#3478F6] text-white disabled:opacity-40"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
