import React from 'react';
import { X, Download } from 'lucide-react';

interface MediaLightboxProps {
  media: { url: string; type: 'photo' | 'video' } | null;
  onClose: () => void;
}

export const MediaLightbox: React.FC<MediaLightboxProps> = ({ media, onClose }) => {
  if (!media) return null;

  return (
    <div
      className="fixed inset-0 z-60 flex items-center justify-center bg-black/95 backdrop-blur-md p-4 animate-fade-in"
      onClick={onClose}
    >
      {/* Close button */}
      <div className="absolute top-4 right-4 flex items-center gap-3 z-70">
        <a
          href={media.url}
          download
          onClick={e => e.stopPropagation()}
          className="p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          title="İndir"
        >
          <Download className="w-5 h-5" />
        </a>
        <button
          onClick={onClose}
          className="p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          title="Kapat"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Media item */}
      <div
        className="max-w-4xl max-h-[90vh] w-full flex items-center justify-center"
        onClick={e => e.stopPropagation()}
      >
        {media.type === 'video' ? (
          <video
            src={media.url}
            controls
            autoPlay
            className="max-w-full max-h-[85vh] rounded-2xl shadow-2xl object-contain"
          />
        ) : (
          <img
            src={media.url}
            alt="Detay"
            className="max-w-full max-h-[85vh] rounded-2xl shadow-2xl object-contain"
          />
        )}
      </div>
    </div>
  );
};
