import React, { useState } from 'react';
import {
  User as UserIcon,
  Heart,
  Calendar,
  Lock,
  LogOut,
  ShieldCheck,
  Camera,
  Music,
  Check,
  AlertCircle,
  Sparkles,
  KeyRound,
  ShieldAlert
} from 'lucide-react';
import { api } from '../api/client';
import { User } from '../types';

interface ProfileViewProps {
  currentUser: User;
  partner: User | null;
  anniversaryDate: string;
  coupleTitle: string;
  onUpdateCurrentUser: (user: User) => void;
  onUpdateAnniversary: (date: string, title?: string) => void;
  onLogout: () => void;
  onNavigateToAdmin: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  currentUser,
  partner,
  anniversaryDate,
  coupleTitle,
  onUpdateCurrentUser,
  onUpdateAnniversary,
  onLogout,
  onNavigateToAdmin,
}) => {
  // Editing states
  const [displayName, setDisplayName] = useState(currentUser.displayName);
  const [bio, setBio] = useState(currentUser.bio || '');
  const [favoriteSong, setFavoriteSong] = useState(currentUser.favoriteSong || '');
  const [editAnniversary, setEditAnniversary] = useState(anniversaryDate);
  const [editCoupleTitle, setEditCoupleTitle] = useState(coupleTitle);

  // Password state
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');

  // Status
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);
  const [avatarUploading, setAvatarUploading] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Avatar file upload
  const handleAvatarFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setAvatarUploading(true);
    setMsg(null);
    try {
      const res = await api.uploadFile(file);
      const updateRes = await api.updateProfile({ avatar: res.url });
      onUpdateCurrentUser(updateRes.user);
      setMsg({ type: 'success', text: 'Profil fotoğrafınız güncellendi.' });
    } catch (err: any) {
      setMsg({ type: 'error', text: err.message || 'Fotoğraf yüklenemedi.' });
    } finally {
      setAvatarUploading(false);
    }
  };

  // Save profile info
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    setMsg(null);
    try {
      const res = await api.updateProfile({
        displayName,
        bio,
        favoriteSong,
      });
      onUpdateCurrentUser(res.user);

      // Save anniversary if changed
      if (editAnniversary !== anniversaryDate || editCoupleTitle !== coupleTitle) {
        await api.updateAnniversary(editAnniversary, editCoupleTitle);
        onUpdateAnniversary(editAnniversary, editCoupleTitle);
      }

      setMsg({ type: 'success', text: 'Profil ve aşk tarihi başarıyla kaydedildi.' });
    } catch (err: any) {
      setMsg({ type: 'error', text: err.message || 'Güncelleme yapılamadı.' });
    } finally {
      setSavingProfile(false);
    }
  };

  // Change password
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!oldPassword || !newPassword) return;

    setSavingPassword(true);
    setMsg(null);
    try {
      await api.changePassword(oldPassword, newPassword);
      setOldPassword('');
      setNewPassword('');
      setMsg({ type: 'success', text: 'Şifreniz başarıyla değiştirildi.' });
    } catch (err: any) {
      setMsg({ type: 'error', text: err.message || 'Şifre değiştirilemedi.' });
    } finally {
      setSavingPassword(false);
    }
  };

  // Logout all devices
  const handleLogoutAll = async () => {
    if (!confirm('Tüm cihazlardaki açık oturumları kapatmak istediğinize emin misiniz?')) return;
    try {
      await api.logoutAll();
      onLogout();
    } catch (err: any) {
      alert(err.message || 'İşlem başarısız.');
    }
  };

  return (
    <div className="max-w-xl mx-auto pb-28 px-4 pt-3 text-white">
      {/* Top Banner / Avatar Header */}
      <div className="relative p-6 rounded-3xl bg-[#11141B] border border-white/10 shadow-2xl mb-6 overflow-hidden">
        <div className="flex flex-col sm:flex-row items-center gap-5">
          {/* Avatar with upload trigger */}
          <div className="relative group">
            <img
              src={currentUser.avatar}
              alt={currentUser.displayName}
              className="w-24 h-24 rounded-full object-cover ring-4 ring-[#3478F6]/30 shadow-xl"
            />
            <label className="absolute inset-0 rounded-full bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity">
              <Camera className="w-6 h-6 text-white" />
              <input
                type="file"
                accept="image/*"
                onChange={handleAvatarFile}
                className="hidden"
              />
            </label>
            {avatarUploading && (
              <div className="absolute inset-0 rounded-full bg-black/70 flex items-center justify-center">
                <span className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              </div>
            )}
          </div>

          {/* User Info */}
          <div className="text-center sm:text-left flex-1">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1">
              <h2 className="text-xl font-bold text-white">{currentUser.displayName}</h2>
              {currentUser.role === 'admin' ? (
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-bold">
                  Kurucu &amp; Yönetici
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[11px] font-bold">
                  Sonsuz Aşkım
                </span>
              )}
            </div>
            <p className="text-xs text-gray-400 mb-2">@{currentUser.username}</p>
            {currentUser.bio && (
              <p className="text-xs text-gray-300 leading-relaxed max-w-sm">
                {currentUser.bio}
              </p>
            )}
          </div>
        </div>

        {/* Partner Card Preview */}
        <div className="mt-5 pt-4 border-t border-white/5 flex items-center justify-between bg-[#191E28]/60 p-3 rounded-2xl">
          <div className="flex items-center gap-3">
            {partner?.avatar ? (
              <img
                src={partner.avatar}
                alt={partner.displayName}
                className="w-10 h-10 rounded-full object-cover ring-2 ring-rose-500/30"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-rose-500/20 flex items-center justify-center text-rose-300 font-bold">
                ❤️
              </div>
            )}
            <div>
              <span className="text-[11px] text-gray-400 block">Diğer Yarım</span>
              <h4 className="text-xs sm:text-sm font-bold text-white">
                {partner ? partner.displayName : 'Katılım Bekleniyor'}
              </h4>
            </div>
          </div>
          <span
            className={`text-xs px-2.5 py-1 rounded-full font-semibold ${
              partner?.isOnline
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-gray-800 text-gray-400'
            }`}
          >
            {partner ? (partner.isOnline ? 'Çevrimiçi' : 'Çevrimdışı') : 'Davet Bekliyor'}
          </span>
        </div>
      </div>

      {/* Admin Panel Quick Jump Button (If role === 'admin') */}
      {currentUser.role === 'admin' && (
        <div className="mb-6 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-amber-200">
                Yönetici Paneli (Kurucu)
              </h4>
              <p className="text-[11px] text-amber-400/80">
                Davet kodları oluşturun, sevgilinizi yönetin, depolama alanını inceleyin.
              </p>
            </div>
          </div>
          <button
            onClick={onNavigateToAdmin}
            className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold transition-all"
          >
            Aç
          </button>
        </div>
      )}

      {/* Message feedback */}
      {msg && (
        <div
          className={`mb-5 p-3 rounded-xl border text-xs flex items-center gap-2 ${
            msg.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300'
              : 'bg-rose-500/10 border-rose-500/20 text-rose-300'
          }`}
        >
          {msg.type === 'success' ? (
            <Check className="w-4 h-4 text-emerald-400" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-400" />
          )}
          <span>{msg.text}</span>
        </div>
      )}

      {/* Profile & Anniversary Edit Form */}
      <div className="p-6 rounded-3xl bg-[#11141B] border border-white/10 shadow-xl mb-6">
        <h3 className="font-bold text-sm text-white mb-4 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#3478F6]" />
          <span>Profil &amp; İlişki Bilgileri</span>
        </h3>

        <form onSubmit={handleSaveProfile} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-300 mb-1">
              Görünen İsim / Hitap
            </label>
            <input
              type="text"
              value={displayName}
              onChange={e => setDisplayName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#191E28] border border-white/10 text-xs text-white focus:outline-none focus:border-[#3478F6]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-300 mb-1">
              Biyografi
            </label>
            <textarea
              rows={2}
              value={bio}
              onChange={e => setBio(e.target.value)}
              placeholder="Aşkınıza dair küçük bir not..."
              className="w-full px-4 py-2.5 rounded-xl bg-[#191E28] border border-white/10 text-xs text-white focus:outline-none focus:border-[#3478F6] resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-300 mb-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-rose-400" />
              <span>İlişki Başlangıç Tarihi (Aşk Sayacı İçin)</span>
            </label>
            <input
              type="date"
              value={editAnniversary}
              onChange={e => setEditAnniversary(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#191E28] border border-white/10 text-xs text-white focus:outline-none focus:border-[#3478F6]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-300 mb-1 flex items-center gap-1">
              <Music className="w-3.5 h-3.5 text-purple-400" />
              <span>Bizim Şarkımız / Favori Melodi</span>
            </label>
            <input
              type="text"
              value={favoriteSong}
              onChange={e => setFavoriteSong(e.target.value)}
              placeholder="Örn: Sezen Aksu - Kaçak"
              className="w-full px-4 py-2.5 rounded-xl bg-[#191E28] border border-white/10 text-xs text-white focus:outline-none focus:border-[#3478F6]"
            />
          </div>

          <button
            type="submit"
            disabled={savingProfile}
            className="w-full py-2.5 rounded-xl bg-[#3478F6] hover:bg-blue-600 font-bold text-xs text-white shadow-sm transition-all"
          >
            {savingProfile ? 'Kaydediliyor...' : 'Değişiklikleri Kaydet'}
          </button>
        </form>
      </div>

      {/* Password Change Form */}
      <div className="p-6 rounded-3xl bg-[#11141B] border border-white/10 shadow-xl mb-6">
        <h3 className="font-bold text-sm text-white mb-4 flex items-center gap-2">
          <Lock className="w-4 h-4 text-emerald-400" />
          <span>Şifre Değiştir</span>
        </h3>

        <form onSubmit={handleChangePassword} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-300 mb-1">
              Mevcut Şifre
            </label>
            <input
              type="password"
              value={oldPassword}
              onChange={e => setOldPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-4 py-2.5 rounded-xl bg-[#191E28] border border-white/10 text-xs text-white focus:outline-none focus:border-[#3478F6]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-300 mb-1">
              Yeni Şifre (En az 6 karakter)
            </label>
            <input
              type="password"
              value={newPassword}
              onChange={e => setNewPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-4 py-2.5 rounded-xl bg-[#191E28] border border-white/10 text-xs text-white focus:outline-none focus:border-[#3478F6]"
            />
          </div>

          <button
            type="submit"
            disabled={savingPassword || !oldPassword || !newPassword}
            className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 font-bold text-xs text-white shadow-sm transition-all"
          >
            {savingPassword ? 'Güncelleniyor...' : 'Şifreyi Güncelle'}
          </button>
        </form>
      </div>

      {/* Logout Actions */}
      <div className="p-6 rounded-3xl bg-[#11141B] border border-white/10 shadow-xl space-y-3">
        <button
          onClick={onLogout}
          className="w-full py-2.5 rounded-xl bg-[#191E28] hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 font-bold text-xs flex items-center justify-center gap-2 transition-all"
        >
          <LogOut className="w-4 h-4" />
          <span>Bu Cihazdan Çıkış Yap</span>
        </button>

        <button
          onClick={handleLogoutAll}
          className="w-full py-2.5 rounded-xl bg-black/40 hover:bg-black/70 text-gray-400 hover:text-white text-xs font-medium transition-all"
        >
          Tüm Cihazlardaki Oturumları Kapat
        </button>
      </div>
    </div>
  );
};
