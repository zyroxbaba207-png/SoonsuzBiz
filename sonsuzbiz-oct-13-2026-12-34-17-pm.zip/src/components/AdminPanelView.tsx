import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Users,
  KeyRound,
  Trash2,
  Copy,
  Check,
  Plus,
  RefreshCw,
  HardDrive,
  AlertTriangle,
  Lock,
  UserCheck,
  UserX,
  HelpCircle,
  FileVideo,
  Image as ImageIcon
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { api } from '../api/client';
import { AdminDashboardData, User } from '../types';

interface AdminPanelViewProps {
  currentUser: User;
}

export const AdminPanelView: React.FC<AdminPanelViewProps> = ({ currentUser }) => {
  const [data, setData] = useState<AdminDashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [partnerNewPassword, setPartnerNewPassword] = useState('');
  const [resettingPassword, setResettingPassword] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      const res = await api.getAdminDashboard();
      setData(res);
    } catch (err: any) {
      alert(err.message || 'Yönetici paneli yüklenemedi.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(code);
    setTimeout(() => setCopiedId(null), 2500);
  };

  // Generate new manual invite code
  const handleGenerateInvite = async () => {
    try {
      await api.generateAdminInvite();
      confetti({ particleCount: 50, spread: 60 });
      fetchDashboard();
    } catch (err: any) {
      alert(err.message || 'Davet kodu oluşturulamadı.');
    }
  };

  // Revoke invite code
  const handleRevokeInvite = async (id: string) => {
    if (!confirm('Bu davet kodunu iptal etmek istediğinize emin misiniz?')) return;
    try {
      await api.revokeAdminInvite(id);
      fetchDashboard();
    } catch (err: any) {
      alert(err.message || 'Kod iptal edilemedi.');
    }
  };

  // Toggle partner active/inactive
  const handleToggleUser = async (userId: string) => {
    try {
      const res = await api.toggleUserStatus(userId);
      setMsg(res.user.isActive ? 'Kullanıcı hesabı aktifleştirildi.' : 'Kullanıcı hesabı devre dışı bırakıldı.');
      fetchDashboard();
    } catch (err: any) {
      alert(err.message || 'İşlem başarısız.');
    }
  };

  // Delete partner account
  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Sevgilinizin hesabını silmek istediğinize emin misiniz? Hesap silindiğinde yeni bir davet kodu ile tekrar kaydolabilir.')) return;
    try {
      await api.deleteUser(userId);
      alert('Hesap silindi.');
      fetchDashboard();
    } catch (err: any) {
      alert(err.message || 'Silinemedi.');
    }
  };

  // Reset partner password
  const handleResetPartnerPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!partnerNewPassword || partnerNewPassword.length < 6) {
      alert('Yeni şifre en az 6 karakter olmalıdır.');
      return;
    }

    setResettingPassword(true);
    try {
      const res = await api.resetPartnerPassword(partnerNewPassword);
      setMsg(res.message);
      setPartnerNewPassword('');
    } catch (err: any) {
      alert(err.message || 'Şifre sıfırlanamadı.');
    } finally {
      setResettingPassword(false);
    }
  };

  if (loading || !data) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="w-8 h-8 border-3 border-amber-400 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const partnerUser = data.users.find(u => u.role === 'partner');

  return (
    <div className="max-w-2xl mx-auto pb-28 px-4 pt-3 text-white">
      {/* Admin Title Header */}
      <div className="flex items-center justify-between p-6 rounded-3xl bg-[#11141B] border border-amber-500/30 shadow-2xl mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shadow-[0_0_20px_rgba(245,158,11,0.2)]">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span>Yönetici &amp; Kurucu Paneli</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono">
                SonsuzBiz Core
              </span>
            </h2>
            <p className="text-xs text-gray-400">
              Yalnızca kurucu hesaba özel sunucu ve kullanıcı yönetimi
            </p>
          </div>
        </div>

        <button
          onClick={fetchDashboard}
          className="p-2.5 rounded-xl bg-[#191E28] hover:bg-[#232938] text-gray-300 hover:text-white transition-colors"
          title="Yenile"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {msg && (
        <div className="mb-5 p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs">
          {msg}
        </div>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <div className="p-4 rounded-2xl bg-[#11141B] border border-white/5">
          <div className="flex items-center justify-between text-gray-400 text-xs mb-1">
            <span>Kullanıcılar</span>
            <Users className="w-4 h-4 text-[#3478F6]" />
          </div>
          <span className="text-xl font-bold text-white">
            {data.users.length} / 2
          </span>
          <span className="block text-[10px] text-gray-500">Maksimum 2 kişi</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#11141B] border border-white/5">
          <div className="flex items-center justify-between text-gray-400 text-xs mb-1">
            <span>Hatıra &amp; Foto</span>
            <ImageIcon className="w-4 h-4 text-rose-400" />
          </div>
          <span className="text-xl font-bold text-white">{data.totalPosts}</span>
          <span className="block text-[10px] text-gray-500">Paylaşılan anı</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#11141B] border border-white/5">
          <div className="flex items-center justify-between text-gray-400 text-xs mb-1">
            <span>Reels Video</span>
            <FileVideo className="w-4 h-4 text-purple-400" />
          </div>
          <span className="text-xl font-bold text-white">{data.totalReels}</span>
          <span className="block text-[10px] text-gray-500">Dikey video</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#11141B] border border-white/5">
          <div className="flex items-center justify-between text-gray-400 text-xs mb-1">
            <span>Depolama</span>
            <HardDrive className="w-4 h-4 text-emerald-400" />
          </div>
          <span className="text-xl font-bold text-white">{data.storageMB} MB</span>
          <span className="block text-[10px] text-gray-500">Medya boyutu</span>
        </div>
      </div>

      {/* Users Section */}
      <div className="p-6 rounded-3xl bg-[#11141B] border border-white/10 shadow-xl mb-6">
        <h3 className="font-bold text-sm text-white mb-4 flex items-center gap-2">
          <Users className="w-4 h-4 text-[#3478F6]" />
          <span>Kayıtlı Kullanıcılar (Kota: 2/2)</span>
        </h3>

        <div className="space-y-3">
          {data.users.map(u => (
            <div
              key={u.id}
              className="flex items-center justify-between p-3.5 rounded-2xl bg-[#191E28] border border-white/5"
            >
              <div className="flex items-center gap-3">
                <img
                  src={u.avatar}
                  alt={u.displayName}
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-white/10"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs sm:text-sm font-bold text-white">
                      {u.displayName}
                    </h4>
                    {u.role === 'admin' ? (
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                        Yönetici (Sen)
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-[10px] font-bold">
                        Sevgilin
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] text-gray-400 block">
                    @{u.username} • {u.isOnline ? '🟢 Çevrimiçi' : '⚪ Çevrimdışı'}
                  </span>
                </div>
              </div>

              {/* Action buttons for partner */}
              {u.role !== 'admin' && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleToggleUser(u.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      u.isActive
                        ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300'
                        : 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300'
                    }`}
                  >
                    {u.isActive ? 'Devre Dışı Bırak' : 'Aktifleştir'}
                  </button>
                  <button
                    onClick={() => handleDeleteUser(u.id)}
                    className="p-2 rounded-xl text-gray-400 hover:text-rose-400 hover:bg-white/5 transition-colors"
                    title="Hesabı Tamamen Sil"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Partner Password Reset by Admin */}
      {partnerUser && (
        <div className="p-6 rounded-3xl bg-[#11141B] border border-white/10 shadow-xl mb-6">
          <h3 className="font-bold text-sm text-white mb-2 flex items-center gap-2">
            <Lock className="w-4 h-4 text-emerald-400" />
            <span>Sevgilinin Şifresini Sıfırla</span>
          </h3>
          <p className="text-xs text-gray-400 mb-4">
            Sevgiliniz şifresini unuttuysa buradan doğrudan yeni bir şifre belirleyebilirsiniz.
          </p>

          <form onSubmit={handleResetPartnerPassword} className="flex gap-2">
            <input
              type="text"
              value={partnerNewPassword}
              onChange={e => setPartnerNewPassword(e.target.value)}
              placeholder="Yeni şifre belirleyin..."
              className="flex-1 px-4 py-2.5 rounded-xl bg-[#191E28] border border-white/10 text-xs text-white focus:outline-none focus:border-emerald-500"
            />
            <button
              type="submit"
              disabled={resettingPassword || !partnerNewPassword}
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-xs font-bold text-white transition-all cursor-pointer"
            >
              {resettingPassword ? 'Kaydediliyor...' : 'Şifreyi Değiştir'}
            </button>
          </form>
        </div>
      )}

      {/* Invite Codes Management */}
      <div className="p-6 rounded-3xl bg-[#11141B] border border-white/10 shadow-xl mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-amber-400" />
            <h3 className="font-bold text-sm text-white">Davet Kodları</h3>
          </div>

          {data.users.length < 2 && (
            <button
              onClick={handleGenerateInvite}
              className="px-3.5 py-1.5 rounded-xl bg-[#3478F6] hover:bg-blue-600 text-xs font-bold text-white flex items-center gap-1.5 transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Yeni Kod Üret</span>
            </button>
          )}
        </div>

        <p className="text-xs text-gray-400 mb-4">
          Sevgilinizin kayıt ekranından istediği kodlar da buraya ve bildirim kutunuza düşer. Tek kullanımlıktır.
        </p>

        {data.inviteCodes.length === 0 ? (
          <div className="py-8 text-center text-gray-500 text-xs">
            Henüz üretilmiş davet kodu bulunmuyor.
          </div>
        ) : (
          <div className="space-y-2.5">
            {data.inviteCodes.map(code => {
              const isExpired = Date.now() > code.expiresAt;
              return (
                <div
                  key={code.id}
                  className={`flex items-center justify-between p-3 rounded-2xl border transition-all ${
                    code.used
                      ? 'bg-[#141822]/40 border-gray-800 opacity-60'
                      : isExpired
                      ? 'bg-rose-500/5 border-rose-500/20'
                      : 'bg-[#191E28] border-amber-500/30'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-sm text-amber-300 tracking-wider">
                      {code.code}
                    </span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                        code.used
                          ? 'bg-gray-800 text-gray-400'
                          : isExpired
                          ? 'bg-rose-500/20 text-rose-300'
                          : 'bg-emerald-500/20 text-emerald-400'
                      }`}
                    >
                      {code.used
                        ? 'Kullanıldı'
                        : isExpired
                        ? 'Süresi Doldu'
                        : 'Aktif (Geçerli)'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {!code.used && !isExpired && (
                      <button
                        onClick={() => handleCopyCode(code.code)}
                        className="px-2.5 py-1.5 rounded-lg bg-[#3478F6] hover:bg-blue-600 text-white text-xs font-semibold flex items-center gap-1 transition-all"
                      >
                        {copiedId === code.code ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-300" />
                            <span>Kopyalandı</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Kopyala</span>
                          </>
                        )}
                      </button>
                    )}

                    <button
                      onClick={() => handleRevokeInvite(code.id)}
                      className="p-1.5 text-gray-400 hover:text-rose-400 hover:bg-white/5 rounded-lg"
                      title="İptal Et"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Free Tier, Storage & Hosting Guide (Bütçe ve Maliyet Raporu) */}
      <div className="p-6 rounded-3xl bg-[#11141B] border border-white/10 shadow-xl">
        <h3 className="font-bold text-sm text-white mb-2 flex items-center gap-2 text-cyan-400">
          <HelpCircle className="w-4 h-4" />
          <span>Ücretsiz Kullanım, Sınırlar ve Maliyet Bilgisi</span>
        </h3>
        <p className="text-xs text-gray-400 mb-4 leading-relaxed">
          Talebiniz doğrultusunda SonsuzBiz sisteminin ücretsiz hizmet limitleri ve olası maliyet analizleri:
        </p>

        <div className="space-y-3 text-xs text-gray-300">
          <div className="p-3 rounded-2xl bg-[#191E28] border border-white/5">
            <h5 className="font-bold text-emerald-400 mb-1">1. Mevcut Yapı (Tamamen Ücretsiz)</h5>
            <p className="text-gray-400 leading-relaxed">
              Uygulama şu an Node.js/Express ve yerel disk depolamasıyla bağımsız çalışır. Sadece siz ve sevgiliniz kullandığı için hiçbir aylık sunucu veya veritabanı lisans ücreti ödemezsiniz.
            </p>
          </div>

          <div className="p-3 rounded-2xl bg-[#191E28] border border-white/5">
            <h5 className="font-bold text-blue-400 mb-1">2. Vercel &amp; Render &amp; Cloud Run</h5>
            <p className="text-gray-400 leading-relaxed">
              İki kişilik bir çiftin aylık mesajlaşması ve video izlemesi bu servislerin ücretsiz paket bant genişliği (aylık 100 GB) sınırının çok altındadır (ortalama 2-5 GB tüketilir).
            </p>
          </div>

          <div className="p-3 rounded-2xl bg-[#191E28] border border-white/5">
            <h5 className="font-bold text-amber-400 mb-1">3. Video Depolama Sınırları</h5>
            <p className="text-gray-400 leading-relaxed">
              Eğer yüzlerce yüksek çözünürlüklü 4K video yüklerseniz ücretsiz disk kotası (500 MB - 1 GB) dolabilir. Videolarınızı telefonunuzda 1080p veya 720p olarak tutarak yüzlerce video ve binlerce fotoğrafı sıfır maliyetle yıllarca saklayabilirsiniz.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
