import {
  User,
  AuthStatus,
  Message,
  Post,
  Reel,
  AppNotification,
  AdminDashboardData,
  InviteCode
} from '../types';

const TOKEN_KEY = 'sonsuzbiz_token';

class ApiClient {
  private token: string | null = null;

  constructor() {
    this.token = localStorage.getItem(TOKEN_KEY);
  }

  public setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem(TOKEN_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_KEY);
    }
  }

  public getToken(): string | null {
    return this.token;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      ...(options.headers as Record<string, string>),
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    if (!(options.body instanceof FormData) && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }

    const res = await fetch(endpoint, {
      ...options,
      headers,
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      throw new Error(data.error || 'Bir hata oluştu. Lütfen tekrar deneyin.');
    }

    return data as T;
  }

  // Auth Status
  async getAuthStatus(): Promise<AuthStatus> {
    return this.request<AuthStatus>('/api/auth/status');
  }

  // Register Admin (First user)
  async registerAdmin(payload: { username: string; displayName: string; password: string }): Promise<{ user: User; token: string }> {
    const res = await this.request<{ user: User; token: string }>('/api/auth/register-admin', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    this.setToken(res.token);
    return res;
  }

  // Request Invite Code (with 5-min cooldown)
  async requestInviteCode(): Promise<{ success: boolean; message: string; cooldownSeconds: number }> {
    return this.request<{ success: boolean; message: string; cooldownSeconds: number }>('/api/auth/request-invite-code', {
      method: 'POST',
    });
  }

  // Register Partner (Requires valid invite code)
  async registerPartner(payload: { username: string; displayName: string; password: string; inviteCode: string }): Promise<{ user: User; token: string }> {
    const res = await this.request<{ user: User; token: string }>('/api/auth/register-partner', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    this.setToken(res.token);
    return res;
  }

  // Login
  async login(payload: { username: string; password: string }): Promise<{ user: User; token: string }> {
    const res = await this.request<{ user: User; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    this.setToken(res.token);
    return res;
  }

  // Logout
  async logout(): Promise<void> {
    try {
      await this.request('/api/auth/logout', { method: 'POST' });
    } finally {
      this.setToken(null);
    }
  }

  // Logout all devices
  async logoutAll(): Promise<void> {
    try {
      await this.request('/api/auth/logout-all', { method: 'POST' });
    } finally {
      this.setToken(null);
    }
  }

  // Get current user and partner info
  async getMe(): Promise<{ user: User; partner: User | null; anniversaryDate: string; coupleTitle: string }> {
    return this.request<{ user: User; partner: User | null; anniversaryDate: string; coupleTitle: string }>('/api/auth/me');
  }

  // Update profile
  async updateProfile(payload: Partial<User>): Promise<{ user: User; message: string }> {
    return this.request<{ user: User; message: string }>('/api/auth/update-profile', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  // Change password
  async changePassword(oldPassword: string, newPassword: string): Promise<{ success: boolean; message: string }> {
    return this.request('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ oldPassword, newPassword }),
    });
  }

  // Anniversary date update
  async updateAnniversary(anniversaryDate: string, coupleTitle?: string): Promise<{ anniversaryDate: string; coupleTitle: string }> {
    return this.request('/api/couple/update-anniversary', {
      method: 'POST',
      body: JSON.stringify({ anniversaryDate, coupleTitle }),
    });
  }

  // Messages
  async getMessages(): Promise<{ messages: Message[]; isPartnerTyping: boolean; partnerLastSeen: number | null; isPartnerOnline: boolean }> {
    return this.request('/api/messages');
  }

  async sendMessage(payload: { text?: string; mediaUrl?: string; mediaType?: 'photo' | 'video' | 'audio' }): Promise<{ message: Message }> {
    return this.request('/api/messages', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  async deleteMessage(id: string): Promise<{ success: boolean }> {
    return this.request(`/api/messages/${id}`, { method: 'DELETE' });
  }

  async toggleReaction(id: string, emoji: string): Promise<{ reactions: Record<string, string[]> }> {
    return this.request(`/api/messages/${id}/reaction`, {
      method: 'POST',
      body: JSON.stringify({ emoji }),
    });
  }

  async pingTyping(): Promise<void> {
    try {
      await this.request('/api/messages/typing', { method: 'POST' });
    } catch {
      // ignore
    }
  }

  // Posts / Moments
  async getPosts(): Promise<{ posts: Post[] }> {
    return this.request('/api/posts');
  }

  async createPost(payload: { mediaUrl: string; mediaType?: 'photo' | 'video'; caption?: string; location?: string }): Promise<{ post: Post }> {
    return this.request('/api/posts', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  async deletePost(id: string): Promise<{ success: boolean }> {
    return this.request(`/api/posts/${id}`, { method: 'DELETE' });
  }

  async togglePostLike(id: string): Promise<{ likes: string[] }> {
    return this.request(`/api/posts/${id}/like`, { method: 'POST' });
  }

  async addPostComment(id: string, text: string): Promise<{ comment: any }> {
    return this.request(`/api/posts/${id}/comment`, {
      method: 'POST',
      body: JSON.stringify({ text }),
    });
  }

  // Reels
  async getReels(): Promise<{ reels: Reel[] }> {
    return this.request('/api/reels');
  }

  async createReel(payload: { videoUrl: string; caption?: string; soundTitle?: string }): Promise<{ reel: Reel }> {
    return this.request('/api/reels', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  async deleteReel(id: string): Promise<{ success: boolean }> {
    return this.request(`/api/reels/${id}`, { method: 'DELETE' });
  }

  async toggleReelLike(id: string): Promise<{ likes: string[] }> {
    return this.request(`/api/reels/${id}/like`, { method: 'POST' });
  }

  async addReelComment(id: string, text: string): Promise<{ comment: any }> {
    return this.request(`/api/reels/${id}/comment`, {
      method: 'POST',
      body: JSON.stringify({ text }),
    });
  }

  // Upload file
  async uploadFile(file: File): Promise<{ url: string; filename: string; mimetype: string; size: number }> {
    const formData = new FormData();
    formData.append('file', file);
    return this.request('/api/upload', {
      method: 'POST',
      body: formData,
    });
  }

  // Notifications
  async getNotifications(): Promise<{ notifications: AppNotification[] }> {
    return this.request('/api/notifications');
  }

  async markNotificationRead(id: string): Promise<{ success: boolean }> {
    return this.request(`/api/notifications/${id}/read`, { method: 'POST' });
  }

  async markAllNotificationsRead(): Promise<{ success: boolean }> {
    return this.request('/api/notifications/read-all', { method: 'POST' });
  }

  // Admin Dashboard
  async getAdminDashboard(): Promise<AdminDashboardData> {
    return this.request('/api/admin/dashboard');
  }

  async generateAdminInvite(): Promise<{ inviteCode: InviteCode }> {
    return this.request('/api/admin/generate-invite', { method: 'POST' });
  }

  async revokeAdminInvite(id: string): Promise<{ success: boolean }> {
    return this.request(`/api/admin/invite-codes/${id}`, { method: 'DELETE' });
  }

  async toggleUserStatus(userId: string): Promise<{ user: User }> {
    return this.request(`/api/admin/toggle-user/${userId}`, { method: 'POST' });
  }

  async deleteUser(userId: string): Promise<{ success: boolean }> {
    return this.request(`/api/admin/users/${userId}`, { method: 'DELETE' });
  }

  async resetPartnerPassword(newPassword: string): Promise<{ success: boolean; message: string }> {
    return this.request('/api/admin/reset-partner-password', {
      method: 'POST',
      body: JSON.stringify({ newPassword }),
    });
  }
}

export const api = new ApiClient();
