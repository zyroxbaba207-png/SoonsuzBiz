export interface User {
  id: string;
  username: string;
  displayName: string;
  role: 'admin' | 'partner';
  avatar: string;
  bio: string;
  chatBackground: string;
  favoriteSong?: string;
  isActive: boolean;
  createdAt: number;
  lastSeen: number;
  isOnline?: boolean;
}

export interface AuthStatus {
  userCount: number;
  maxUsers: number;
  allowsFirstAdminRegister: boolean;
  hasAdmin: boolean;
  isCoupleComplete: boolean;
  rateLimitRemainingSeconds: number;
  coupleTitle: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  text: string;
  mediaUrl?: string;
  mediaType?: 'photo' | 'video' | 'audio';
  timestamp: number;
  status: 'sent' | 'delivered' | 'read';
  reactions?: Record<string, string[]>;
}

export interface PostComment {
  id: string;
  userId: string;
  text: string;
  createdAt: number;
}

export interface Post {
  id: string;
  authorId: string;
  mediaUrl: string;
  mediaType: 'photo' | 'video';
  caption: string;
  location?: string;
  createdAt: number;
  likes: string[];
  comments: PostComment[];
  author?: {
    id: string;
    username: string;
    displayName: string;
    avatar: string;
  } | null;
}

export interface Reel {
  id: string;
  authorId: string;
  videoUrl: string;
  caption: string;
  soundTitle?: string;
  createdAt: number;
  likes: string[];
  comments: PostComment[];
  author?: {
    id: string;
    username: string;
    displayName: string;
    avatar: string;
  } | null;
}

export interface AppNotification {
  id: string;
  targetUserId: string;
  type: 'invite_request' | 'invite_code' | 'new_message' | 'like' | 'comment' | 'system';
  title: string;
  message: string;
  metadata?: any;
  read: boolean;
  createdAt: number;
}

export interface InviteCode {
  id: string;
  code: string;
  createdBy: string;
  createdAt: number;
  expiresAt: number;
  used: boolean;
  usedBy: string | null;
  usedAt: number | null;
}

export interface AdminDashboardData {
  users: User[];
  inviteCodes: InviteCode[];
  totalPosts: number;
  totalReels: number;
  totalMessages: number;
  totalUploadSizeBytes: number;
  storageMB: string;
}
