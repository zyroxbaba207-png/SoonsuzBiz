/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Heart, Bell, ShieldAlert, Sparkles, MessageCircleHeart } from 'lucide-react';
import { api } from './api/client';
import { AuthStatus, User, AppNotification } from './types';
import { NavigationDock, TabType } from './components/NavigationDock';
import { AuthModal } from './components/AuthModal';
import { NotificationModal } from './components/NotificationModal';
import { FeedView } from './components/FeedView';
import { ReelsView } from './components/ReelsView';
import { ChatView } from './components/ChatView';
import { ProfileView } from './components/ProfileView';
import { AdminPanelView } from './components/AdminPanelView';
import { UploadModal } from './components/UploadModal';
import { MediaLightbox } from './components/MediaLightbox';

export default function App() {
  const [authStatus, setAuthStatus] = useState<AuthStatus | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [partner, setPartner] = useState<User | null>(null);
  const [anniversaryDate, setAnniversaryDate] = useState('2024-05-18');
  const [coupleTitle, setCoupleTitle] = useState('SonsuzBiz');

  // Navigation
  const [activeTab, setActiveTab] = useState<TabType>('feed');

  // Modals & Overlays
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadDefaultType, setUploadDefaultType] = useState<'post' | 'reel'>('post');
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  const [lightboxMedia, setLightboxMedia] = useState<{ url: string; type: 'photo' | 'video' } | null>(null);

  // Notifications & Messages
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [unreadMessagesCount, setUnreadMessagesCount] = useState(0);
  const [initialLoading, setInitialLoading] = useState(true);

  // Fetch initial authentication status
  const fetchStatus = async () => {
    try {
      const status = await api.getAuthStatus();
      setAuthStatus(status);
      setCoupleTitle(status.coupleTitle || 'SonsuzBiz');
    } catch (err) {
      console.error('Auth status error:', err);
    }
  };

  // Fetch current user details
  const fetchUserData = async () => {
    try {
      const me = await api.getMe();
      setCurrentUser(me.user);
      setPartner(me.partner);
      setAnniversaryDate(me.anniversaryDate || '2024-05-18');
      setCoupleTitle(me.coupleTitle || 'SonsuzBiz');
    } catch (err) {
      // Token invalid or expired
      api.setToken(null);
      setCurrentUser(null);
    }
  };

  // Fetch notifications
  const fetchNotifications = async () => {
    if (!api.getToken()) return;
    try {
      const res = await api.getNotifications();
      setNotifications(res.notifications);
    } catch (err) {
      // quiet
    }
  };

  // Initialize app
  useEffect(() => {
    const init = async () => {
      setInitialLoading(true);
      await fetchStatus();
      if (api.getToken()) {
        await fetchUserData();
        await fetchNotifications();
      }
      setInitialLoading(false);
    };

    init();
  }, []);

  // Periodic poll for notifications and partner presence (every 4 seconds)
  useEffect(() => {
    if (!currentUser) return;
    const interval = setInterval(() => {
      fetchNotifications();
      // Also softly refresh status for rate limits
      fetchStatus();
    }, 4000);
    return () => clearInterval(interval);
  }, [currentUser]);

  // Handle successful login or register
  const handleAuthSuccess = (user: User) => {
    setCurrentUser(user);
    fetchUserData();
    fetchNotifications();
    fetchStatus();
  };

  // Handle logout
  const handleLogout = async () => {
    await api.logout();
    setCurrentUser(null);
    setPartner(null);
    setActiveTab('feed');
    fetchStatus();
  };

  // Notification handlers
  const handleMarkNotificationRead = async (id: string) => {
    try {
      await api.markNotificationRead(id);
      setNotifications(prev => prev.map(n => (n.id === id ? { ...n, read: true } : n)));
    } catch (err) {
      // quiet
    }
  };

  const handleMarkAllNotificationsRead = async () => {
    try {
      await api.markAllNotificationsRead();
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    } catch (err) {
      // quiet
    }
  };

  if (initialLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#08090D] text-white">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#3478F6] via-indigo-600 to-rose-500 flex items-center justify-center mb-4 shadow-[0_0_30px_rgba(52,120,246,0.5)]">
          <Heart className="w-8 h-8 text-white fill-white/30 animate-pulse" />
        </div>
        <h1 className="text-xl font-bold tracking-tight">SonsuzBiz</h1>
        <p className="text-xs text-gray-500 mt-1">Özel aşk alanınız hazırlanıyor...</p>
      </div>
    );
  }

  // If not logged in, show AuthModal
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#08090D]">
        {authStatus && (
          <AuthModal
            authStatus={authStatus}
            onSuccess={handleAuthSuccess}
            onRefreshStatus={fetchStatus}
          />
        )}
      </div>
    );
  }

  const unreadNotifsCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-[#08090D] text-gray-100 flex flex-col selection:bg-[#3478F6] selection:text-white">
      {/* Top Application Header */}
      <header className="sticky top-0 z-30 flex items-center justify-between px-4 sm:px-6 py-3 bg-[#08090D]/85 backdrop-blur-xl border-b border-white/5">
        <div className="flex items-center gap-3">
          <div
            onClick={() => setActiveTab('feed')}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#3478F6] to-rose-500 flex items-center justify-center shadow-[0_0_15px_rgba(52,120,246,0.3)] transition-transform group-hover:scale-105">
              <Heart className="w-5 h-5 text-white fill-white/40" />
            </div>
            <div>
              <span className="font-extrabold text-base tracking-tight text-white flex items-center gap-1.5">
                <span>{coupleTitle}</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-white/10 text-gray-300 font-mono font-normal">
                  2 Kişilik Özel
                </span>
              </span>
            </div>
          </div>
        </div>

        {/* Header Right Actions */}
        <div className="flex items-center gap-2.5">
          {/* Partner online indicator pill */}
          {partner && (
            <div
              onClick={() => setActiveTab('chat')}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#11141B] border border-white/10 cursor-pointer hover:border-white/20 transition-all text-xs"
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  partner.isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-gray-500'
                }`}
              />
              <span className="text-gray-300 font-medium truncate max-w-[100px]">
                {partner.displayName}
              </span>
            </div>
          )}

          {/* Notification Bell */}
          <button
            onClick={() => setShowNotificationModal(true)}
            className="relative p-2.5 rounded-full bg-[#11141B] hover:bg-[#191E28] border border-white/10 text-gray-300 hover:text-white transition-all cursor-pointer"
            title="Bildirim Kutusu"
          >
            <Bell className="w-4 h-4" />
            {unreadNotifsCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow-sm animate-pulse">
                {unreadNotifsCount > 9 ? '9+' : unreadNotifsCount}
              </span>
            )}
          </button>

          {/* Quick Admin Icon if Admin */}
          {currentUser.role === 'admin' && (
            <button
              onClick={() => setActiveTab('admin')}
              className={`p-2.5 rounded-full border transition-all cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-amber-500 text-black border-amber-400 font-bold'
                  : 'bg-[#11141B] text-amber-400 hover:bg-amber-500/10 border-amber-500/30'
              }`}
              title="Yönetici Paneli"
            >
              <ShieldAlert className="w-4 h-4" />
            </button>
          )}
        </div>
      </header>

      {/* Main Content Pages */}
      <main className="flex-1 w-full">
        {activeTab === 'feed' && (
          <FeedView
            currentUser={currentUser}
            anniversaryDate={anniversaryDate}
            coupleTitle={coupleTitle}
            onOpenUpload={() => {
              setUploadDefaultType('post');
              setShowUploadModal(true);
            }}
            onOpenMediaLightbox={(url, type) => setLightboxMedia({ url, type })}
          />
        )}

        {activeTab === 'reels' && (
          <ReelsView
            currentUser={currentUser}
            onOpenUploadVideo={() => {
              setUploadDefaultType('reel');
              setShowUploadModal(true);
            }}
          />
        )}

        {activeTab === 'chat' && (
          <div className="p-2 sm:p-4 pb-20 sm:pb-24">
            <ChatView
              currentUser={currentUser}
              partner={partner}
              onOpenMediaLightbox={(url, type) => setLightboxMedia({ url, type })}
              onUpdateCurrentUser={setCurrentUser}
            />
          </div>
        )}

        {activeTab === 'profile' && (
          <ProfileView
            currentUser={currentUser}
            partner={partner}
            anniversaryDate={anniversaryDate}
            coupleTitle={coupleTitle}
            onUpdateCurrentUser={setCurrentUser}
            onUpdateAnniversary={(date, title) => {
              setAnniversaryDate(date);
              if (title) setCoupleTitle(title);
            }}
            onLogout={handleLogout}
            onNavigateToAdmin={() => setActiveTab('admin')}
          />
        )}

        {activeTab === 'admin' && currentUser.role === 'admin' && (
          <AdminPanelView currentUser={currentUser} />
        )}
      </main>

      {/* Capsule-Shaped Floating Dock Navigation Menu */}
      <NavigationDock
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenUpload={() => {
          setUploadDefaultType(activeTab === 'reels' ? 'reel' : 'post');
          setShowUploadModal(true);
        }}
        unreadMessagesCount={unreadMessagesCount}
        currentUser={currentUser}
      />

      {/* Upload Modal */}
      <UploadModal
        isOpen={showUploadModal}
        defaultType={uploadDefaultType}
        onClose={() => setShowUploadModal(false)}
        onSuccess={() => {
          // Trigger refresh based on active view
          fetchStatus();
        }}
      />

      {/* Notification Center Modal */}
      <NotificationModal
        isOpen={showNotificationModal}
        notifications={notifications}
        onClose={() => setShowNotificationModal(false)}
        onMarkRead={handleMarkNotificationRead}
        onMarkAllRead={handleMarkAllNotificationsRead}
      />

      {/* Fullscreen Media Lightbox */}
      <MediaLightbox
        media={lightboxMedia}
        onClose={() => setLightboxMedia(null)}
      />
    </div>
  );
}
