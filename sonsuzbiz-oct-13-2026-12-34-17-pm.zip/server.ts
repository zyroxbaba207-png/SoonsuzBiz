import express, { Request, Response, NextFunction } from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import multer from 'multer';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Ensure data and uploads folders exist
const DATA_DIR = path.join(process.cwd(), 'data');
const UPLOADS_DIR = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const DB_PATH = path.join(DATA_DIR, 'db.json');

// Types
export interface User {
  id: string;
  username: string;
  displayName: string;
  passwordHash: string;
  salt: string;
  role: 'admin' | 'partner';
  avatar: string;
  bio: string;
  chatBackground: string;
  favoriteSong?: string;
  isActive: boolean;
  createdAt: number;
  lastSeen: number;
}

export interface Session {
  token: string;
  userId: string;
  createdAt: number;
}

export interface InviteCode {
  id: string;
  code: string;
  createdBy: string;
  createdAt: number;
  expiresAt: number;
  used: boolean;
  usedBy: string | null;
  usedAt: number | null;
}

export interface InviteRequestLog {
  id: string;
  requestedAt: number;
  ip: string;
  generatedCode: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  text: string;
  mediaUrl?: string;
  mediaType?: 'photo' | 'video' | 'audio';
  timestamp: number;
  status: 'sent' | 'delivered' | 'read';
  reactions?: Record<string, string[]>; // emoji -> array of userIds
}

export interface PostComment {
  id: string;
  userId: string;
  text: string;
  createdAt: number;
}

export interface Post {
  id: string;
  authorId: string;
  mediaUrl: string;
  mediaType: 'photo' | 'video';
  caption: string;
  location?: string;
  createdAt: number;
  likes: string[]; // userIds
  comments: PostComment[];
}

export interface Reel {
  id: string;
  authorId: string;
  videoUrl: string;
  caption: string;
  soundTitle?: string;
  createdAt: number;
  likes: string[]; // userIds
  comments: PostComment[];
}

export interface Notification {
  id: string;
  targetUserId: string;
  type: 'invite_request' | 'invite_code' | 'new_message' | 'like' | 'comment' | 'system';
  title: string;
  message: string;
  metadata?: any;
  read: boolean;
  createdAt: number;
}

interface Database {
  users: User[];
  sessions: Session[];
  inviteCodes: InviteCode[];
  inviteRequestLogs: InviteRequestLog[];
  messages: Message[];
  posts: Post[];
  reels: Reel[];
  notifications: Notification[];
  anniversaryDate: string; // ISO string e.g. "2024-05-18"
  coupleTitle: string;
}

// Initial Database Structure
function getDefaultDatabase(): Database {
  return {
    users: [],
    sessions: [],
    inviteCodes: [],
    inviteRequestLogs: [],
    messages: [],
    posts: [],
    reels: [],
    notifications: [],
    anniversaryDate: '2024-05-18',
    coupleTitle: 'SonsuzBiz',
  };
}

// Database helper functions with atomic writes
function loadDb(): Database {
  try {
    if (fs.existsSync(DB_PATH)) {
      const data = fs.readFileSync(DB_PATH, 'utf-8');
      const parsed = JSON.parse(data);
      return { ...getDefaultDatabase(), ...parsed };
    }
  } catch (err) {
    console.error('Database read error, initializing fallback:', err);
  }
  const defaultDb = getDefaultDatabase();
  saveDb(defaultDb);
  return defaultDb;
}

function saveDb(data: Database): void {
  try {
    const tempPath = `${DB_PATH}.tmp`;
    fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tempPath, DB_PATH);
  } catch (err) {
    console.error('Database write error:', err);
  }
}

// Password hashing helper using crypto PBKDF2
function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const generatedSalt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, generatedSalt, 10000, 64, 'sha512').toString('hex');
  return { hash, salt: generatedSalt };
}

function verifyPassword(password: string, hash: string, salt: string): boolean {
  const verifiedHash = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
  return crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(verifiedHash));
}

// Typing indicators in-memory store
const userTypingMap = new Map<string, number>();

// Multer storage for media uploads
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const unique = `${Date.now()}-${crypto.randomBytes(6).toString('hex')}${ext}`;
    cb(null, unique);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB limit for couple videos/photos
  },
  fileFilter: (_req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp|gif|mp4|webm|quicktime|mov/;
    const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
    const mime = file.mimetype;
    if (allowed.test(ext) || allowed.test(mime)) {
      cb(null, true);
    } else {
      cb(new Error('Desteklenmeyen dosya formatı. Yalnızca fotoğraf ve video yükleyebilirsiniz.'));
    }
  },
});

// Middleware configuration
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve uploaded files statically
app.use('/uploads', express.static(UPLOADS_DIR));

// Authentication Middleware
interface AuthenticatedRequest extends Request {
  user?: User;
}

function authMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ') ? authHeader.substring(7) : (req.headers['x-session-token'] as string);

  if (!token) {
    res.status(401).json({ error: 'Oturum açılmadı veya yetkisiz istek.' });
    return;
  }

  const db = loadDb();
  const session = db.sessions.find(s => s.token === token);
  if (!session) {
    res.status(401).json({ error: 'Geçersiz veya süresi dolmuş oturum.' });
    return;
  }

  const user = db.users.find(u => u.id === session.userId);
  if (!user) {
    res.status(401).json({ error: 'Kullanıcı bulunamadı.' });
    return;
  }

  if (!user.isActive) {
    res.status(403).json({ error: 'Hesabınız yönetici tarafından devre dışı bırakılmıştır.' });
    return;
  }

  // Update last seen
  user.lastSeen = Date.now();
  saveDb(db);

  req.user = user;
  next();
}

function adminOnlyMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user || req.user.role !== 'admin') {
    res.status(403).json({ error: 'Bu işlem yalnızca yönetici (kurucu) hesabına açıktır.' });
    return;
  }
  next();
}

// -----------------------------------------------------------------------------
// AUTH & REGISTRATION API
// -----------------------------------------------------------------------------

// 1. Auth Status & System Mode
app.get('/api/auth/status', (req: Request, res: Response) => {
  const db = loadDb();
  const userCount = db.users.length;
  const adminUser = db.users.find(u => u.role === 'admin');

  // Check rate limit for invite code requests (5 minutes cooldown = 300 seconds)
  const lastRequest = db.inviteRequestLogs.length > 0 ? db.inviteRequestLogs[db.inviteRequestLogs.length - 1] : null;
  let remainingSeconds = 0;
  if (lastRequest) {
    const elapsed = Math.floor((Date.now() - lastRequest.requestedAt) / 1000);
    if (elapsed < 300) {
      remainingSeconds = 300 - elapsed;
    }
  }

  res.json({
    userCount,
    maxUsers: 2,
    allowsFirstAdminRegister: userCount === 0,
    hasAdmin: !!adminUser,
    isCoupleComplete: userCount >= 2,
    rateLimitRemainingSeconds: remainingSeconds,
    coupleTitle: db.coupleTitle,
  });
});

// 2. Register First User as Admin (Kurucu / Yönetici)
app.post('/api/auth/register-admin', (req: Request, res: Response) => {
  const { username, displayName, password } = req.body;
  const db = loadDb();

  if (db.users.length > 0) {
    res.status(403).json({ error: 'İlk yönetici hesabı zaten oluşturulmuş.' });
    return;
  }

  if (!username || !displayName || !password) {
    res.status(400).json({ error: 'Lütfen kullanıcı adı, görünen isim ve şifre giriniz.' });
    return;
  }

  if (password.length < 6) {
    res.status(400).json({ error: 'Şifreniz en az 6 karakter olmalıdır.' });
    return;
  }

  const { hash, salt } = hashPassword(password);
  const newUser: User = {
    id: `user-${crypto.randomUUID()}`,
    username: username.trim().toLowerCase(),
    displayName: displayName.trim(),
    passwordHash: hash,
    salt,
    role: 'admin',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&h=300&fit=crop&crop=faces',
    bio: 'SonsuzBiz Kurucusu & Yöneticisi ❤️',
    chatBackground: 'starry',
    isActive: true,
    createdAt: Date.now(),
    lastSeen: Date.now(),
  };

  const sessionToken = crypto.randomBytes(32).toString('hex');
  db.users.push(newUser);
  db.sessions.push({
    token: sessionToken,
    userId: newUser.id,
    createdAt: Date.now(),
  });

  // Welcome notification
  db.notifications.push({
    id: `notif-${crypto.randomUUID()}`,
    targetUserId: newUser.id,
    type: 'system',
    title: 'SonsuzBiz Dünyasına Hoş Geldiniz! 💍',
    message: 'İlk yönetici hesabı kuruldu. Sevgilinizin kaydolabilmesi için "Yönetici Paneli"nden davet kodu üretebilir veya sevgilinizin davet kodu isteğinde bulunmasını sağlayabilirsiniz.',
    read: false,
    createdAt: Date.now(),
  });

  saveDb(db);

  const { passwordHash: _, salt: __, ...safeUser } = newUser;
  res.json({
    user: safeUser,
    token: sessionToken,
    message: 'Yönetici hesabı başarıyla oluşturuldu.',
  });
});

// 3. Request New Invite Code (5 Minutes Cooldown)
// "kanka kayıt olmak yerine yeni davet kodu gönder butonu ekle ve her biri bastığında yönetici hesabıma yeni kod gelsin fakat 5 dakikada bir kod göndermek olsun"
app.post('/api/auth/request-invite-code', (req: Request, res: Response) => {
  const db = loadDb();

  if (db.users.length === 0) {
    res.status(400).json({ error: 'Henüz sistemde yönetici hesabı oluşturulmamış.' });
    return;
  }

  if (db.users.length >= 2) {
    res.status(403).json({ error: 'SonsuzBiz 2 kişilik çift kotasını doldurmuştur. Yeni kayıt kabul edilmemektedir.' });
    return;
  }

  const adminUser = db.users.find(u => u.role === 'admin');
  if (!adminUser) {
    res.status(500).json({ error: 'Yönetici hesabı bulunamadı.' });
    return;
  }

  // Enforce 5-minute cooldown (300 seconds)
  const lastRequest = db.inviteRequestLogs.length > 0 ? db.inviteRequestLogs[db.inviteRequestLogs.length - 1] : null;
  if (lastRequest) {
    const elapsedSeconds = Math.floor((Date.now() - lastRequest.requestedAt) / 1000);
    if (elapsedSeconds < 300) {
      const waitRemaining = 300 - elapsedSeconds;
      res.status(429).json({
        error: `Yeni davet kodu istemek için lütfen ${waitRemaining} saniye bekleyin. Güvenlik gereği davet kodu 5 dakikada bir gönderilebilir.`,
        remainingSeconds: waitRemaining,
      });
      return;
    }
  }

  // Generate fresh, memorable 6-character code
  const codeSuffix = Math.floor(100000 + Math.random() * 900000).toString();
  const inviteCodeStr = `BIZ-${codeSuffix.substring(0, 4)}`;

  const newInviteCode: InviteCode = {
    id: `inv-${crypto.randomUUID()}`,
    code: inviteCodeStr,
    createdBy: adminUser.id,
    createdAt: Date.now(),
    expiresAt: Date.now() + 15 * 60 * 1000, // 15 mins expiry
    used: false,
    usedBy: null,
    usedAt: null,
  };

  db.inviteCodes.push(newInviteCode);

  // Log request for 5-minute rate limit
  const clientIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || 'unknown';
  db.inviteRequestLogs.push({
    id: `req-${crypto.randomUUID()}`,
    requestedAt: Date.now(),
    ip: clientIp,
    generatedCode: inviteCodeStr,
  });

  // Create High-Priority Notification for Admin
  db.notifications.push({
    id: `notif-${crypto.randomUUID()}`,
    targetUserId: adminUser.id,
    type: 'invite_code',
    title: '❤️ Sevgilinden Yeni Davet Kodu Talebi!',
    message: `Sevgilin SonsuzBiz'e katılmak için davet kodu istedi. Yeni tek kullanımlık davet kodu: ${inviteCodeStr} (15 dakika geçerlidir). Bu kodu sevgiline WhatsApp veya SMS ile iletebilirsin.`,
    metadata: {
      code: inviteCodeStr,
      expiresAt: newInviteCode.expiresAt,
    },
    read: false,
    createdAt: Date.now(),
  });

  saveDb(db);

  res.json({
    success: true,
    message: 'Yeni davet kodu başarıyla oluşturuldu ve sevgilinin (yöneticinin) bildirim kutusuna gönderildi! Kodu sevgilinden alıp aşağıdaki alana girerek kaydını tamamla.',
    cooldownSeconds: 300,
  });
});

// 4. Register Partner with Invite Code
app.post('/api/auth/register-partner', (req: Request, res: Response) => {
  const { username, displayName, password, inviteCode } = req.body;
  const db = loadDb();

  if (db.users.length >= 2) {
    res.status(403).json({ error: 'SonsuzBiz kontenjanı doludur (Maksimum 2 kullanıcı).' });
    return;
  }

  if (!username || !displayName || !password || !inviteCode) {
    res.status(400).json({ error: 'Lütfen kullanıcı adı, isim, şifre ve davet kodunu eksiksiz giriniz.' });
    return;
  }

  if (password.length < 6) {
    res.status(400).json({ error: 'Şifreniz en az 6 karakter olmalıdır.' });
    return;
  }

  // Check username collision
  const existingUser = db.users.find(u => u.username === username.trim().toLowerCase());
  if (existingUser) {
    res.status(400).json({ error: 'Bu kullanıcı adı zaten alınmış.' });
    return;
  }

  // Validate Invite Code
  const normalizedCode = inviteCode.trim().toUpperCase();
  const validCode = db.inviteCodes.find(
    c => c.code.toUpperCase() === normalizedCode && !c.used && c.expiresAt > Date.now()
  );

  if (!validCode) {
    res.status(400).json({ error: 'Geçersiz, kullanılmış veya süresi dolmuş davet kodu. Lütfen "Yöneticiye Davet Kodu Gönder" butonuna basarak sevgilinizden yeni kod isteyin.' });
    return;
  }

  const { hash, salt } = hashPassword(password);
  const newPartner: User = {
    id: `user-${crypto.randomUUID()}`,
    username: username.trim().toLowerCase(),
    displayName: displayName.trim(),
    passwordHash: hash,
    salt,
    role: 'partner',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&h=300&fit=crop&crop=faces',
    bio: 'SonsuzBiz aşkımın diğer yarısı 💕',
    chatBackground: 'hearts',
    isActive: true,
    createdAt: Date.now(),
    lastSeen: Date.now(),
  };

  // Consume invite code (one-time use!)
  validCode.used = true;
  validCode.usedBy = newPartner.id;
  validCode.usedAt = Date.now();

  const sessionToken = crypto.randomBytes(32).toString('hex');
  db.users.push(newPartner);
  db.sessions.push({
    token: sessionToken,
    userId: newPartner.id,
    createdAt: Date.now(),
  });

  // Notify admin that partner joined!
  const adminUser = db.users.find(u => u.role === 'admin');
  if (adminUser) {
    db.notifications.push({
      id: `notif-${crypto.randomUUID()}`,
      targetUserId: adminUser.id,
      type: 'system',
      title: '🎉 Sevgilin SonsuzBiz\'e Katıldı!',
      message: `${newPartner.displayName} (@${newPartner.username}) davet kodunu kullanarak başarıyla katıldı. Artık özel mesajlaşabilir, video ve fotoğraf paylaşabilirsiniz!`,
      read: false,
      createdAt: Date.now(),
    });
  }

  // Welcome message in chat
  db.messages.push({
    id: `msg-${crypto.randomUUID()}`,
    senderId: adminUser ? adminUser.id : 'system',
    receiverId: newPartner.id,
    text: `Hoş geldin bir tanem ❤️ SonsuzBiz'e katıldığın için çok mutluyum! Burası sadece bizim dünyamız ✨`,
    timestamp: Date.now(),
    status: 'sent',
  });

  saveDb(db);

  const { passwordHash: _, salt: __, ...safeUser } = newPartner;
  res.json({
    user: safeUser,
    token: sessionToken,
    message: 'Kayıt başarılı! Hoş geldiniz.',
  });
});

// 5. Login
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { username, password } = req.body;

  if (!username || !password) {
    res.status(400).json({ error: 'Kullanıcı adı ve şifre gereklidir.' });
    return;
  }

  const db = loadDb();
  const user = db.users.find(u => u.username === username.trim().toLowerCase());

  if (!user) {
    res.status(401).json({ error: 'Kullanıcı adı veya şifre hatalı.' });
    return;
  }

  if (!user.isActive) {
    res.status(403).json({ error: 'Hesabınız yönetici tarafından devre dışı bırakılmıştır.' });
    return;
  }

  const isValid = verifyPassword(password, user.passwordHash, user.salt);
  if (!isValid) {
    res.status(401).json({ error: 'Kullanıcı adı veya şifre hatalı.' });
    return;
  }

  const sessionToken = crypto.randomBytes(32).toString('hex');
  db.sessions.push({
    token: sessionToken,
    userId: user.id,
    createdAt: Date.now(),
  });
  user.lastSeen = Date.now();
  saveDb(db);

  const { passwordHash: _, salt: __, ...safeUser } = user;
  res.json({
    user: safeUser,
    token: sessionToken,
    message: 'Giriş başarılı.',
  });
});

// 6. Logout Current Session
app.post('/api/auth/logout', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const token = req.headers.authorization?.substring(7) || (req.headers['x-session-token'] as string);
  const db = loadDb();
  db.sessions = db.sessions.filter(s => s.token !== token);
  saveDb(db);
  res.json({ success: true, message: 'Oturum kapatıldı.' });
});

// 7. Logout All Devices
app.post('/api/auth/logout-all', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const db = loadDb();
  db.sessions = db.sessions.filter(s => s.userId !== req.user!.id);
  saveDb(db);
  res.json({ success: true, message: 'Tüm cihazlardaki oturumlar kapatıldı.' });
});

// 8. Get Current Profile & Partner Info
app.get('/api/auth/me', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const db = loadDb();
  const currentUser = req.user!;
  const partner = db.users.find(u => u.id !== currentUser.id);

  let safePartner = null;
  if (partner) {
    const { passwordHash: _, salt: __, ...partnerData } = partner;
    // Check if partner is online (seen in last 3 minutes)
    const isOnline = Date.now() - partner.lastSeen < 3 * 60 * 1000;
    safePartner = { ...partnerData, isOnline };
  }

  const { passwordHash: _, salt: __, ...safeCurrentUser } = currentUser;
  res.json({
    user: safeCurrentUser,
    partner: safePartner,
    anniversaryDate: db.anniversaryDate,
    coupleTitle: db.coupleTitle,
  });
});

// 9. Update Profile
app.post('/api/auth/update-profile', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { displayName, bio, avatar, chatBackground, favoriteSong } = req.body;
  const db = loadDb();
  const user = db.users.find(u => u.id === req.user!.id);

  if (!user) {
    res.status(404).json({ error: 'Kullanıcı bulunamadı.' });
    return;
  }

  if (displayName) user.displayName = displayName.trim();
  if (bio !== undefined) user.bio = bio.trim();
  if (avatar) user.avatar = avatar;
  if (chatBackground) user.chatBackground = chatBackground;
  if (favoriteSong !== undefined) user.favoriteSong = favoriteSong;

  saveDb(db);
  const { passwordHash: _, salt: __, ...safeUser } = user;
  res.json({ user: safeUser, message: 'Profil başarıyla güncellendi.' });
});

// 10. Change Password
app.post('/api/auth/change-password', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { oldPassword, newPassword } = req.body;
  if (!oldPassword || !newPassword || newPassword.length < 6) {
    res.status(400).json({ error: 'Yeni şifre en az 6 karakter olmalıdır.' });
    return;
  }

  const db = loadDb();
  const user = db.users.find(u => u.id === req.user!.id);
  if (!user) {
    res.status(404).json({ error: 'Kullanıcı bulunamadı.' });
    return;
  }

  const isOldValid = verifyPassword(oldPassword, user.passwordHash, user.salt);
  if (!isOldValid) {
    res.status(400).json({ error: 'Mevcut şifreniz yanlış.' });
    return;
  }

  const { hash, salt } = hashPassword(newPassword);
  user.passwordHash = hash;
  user.salt = salt;
  saveDb(db);

  res.json({ success: true, message: 'Şifreniz başarıyla değiştirildi.' });
});

// -----------------------------------------------------------------------------
// COUPLE & ANNIVERSARY
// -----------------------------------------------------------------------------

app.post('/api/couple/update-anniversary', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { anniversaryDate, coupleTitle } = req.body;
  const db = loadDb();

  if (anniversaryDate) db.anniversaryDate = anniversaryDate;
  if (coupleTitle) db.coupleTitle = coupleTitle;

  saveDb(db);
  res.json({
    anniversaryDate: db.anniversaryDate,
    coupleTitle: db.coupleTitle,
    message: 'Tarih güncellendi.',
  });
});

// -----------------------------------------------------------------------------
// CHAT & MESSAGING API
// -----------------------------------------------------------------------------

// Get messages and poll updates
app.get('/api/messages', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const db = loadDb();
  const currentUserId = req.user!.id;
  const partner = db.users.find(u => u.id !== currentUserId);

  // Mark all unread incoming messages as read
  let hasUpdatedRead = false;
  db.messages.forEach(msg => {
    if (msg.receiverId === currentUserId && msg.status !== 'read') {
      msg.status = 'read';
      hasUpdatedRead = true;
    }
  });

  if (hasUpdatedRead) {
    saveDb(db);
  }

  // Check if partner is typing
  let isPartnerTyping = false;
  if (partner) {
    const lastTypingTime = userTypingMap.get(partner.id) || 0;
    isPartnerTyping = Date.now() - lastTypingTime < 3500;
  }

  res.json({
    messages: db.messages,
    isPartnerTyping,
    partnerLastSeen: partner ? partner.lastSeen : null,
    isPartnerOnline: partner ? Date.now() - partner.lastSeen < 3 * 60 * 1000 : false,
  });
});

// Send new message
app.post('/api/messages', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { text, mediaUrl, mediaType } = req.body;
  if (!text && !mediaUrl) {
    res.status(400).json({ error: 'Mesaj metni veya medya gereklidir.' });
    return;
  }

  const db = loadDb();
  const currentUserId = req.user!.id;
  const partner = db.users.find(u => u.id !== currentUserId);

  const receiverId = partner ? partner.id : 'unknown';

  const newMessage: Message = {
    id: `msg-${crypto.randomUUID()}`,
    senderId: currentUserId,
    receiverId,
    text: text ? text.trim() : '',
    mediaUrl,
    mediaType,
    timestamp: Date.now(),
    status: partner && Date.now() - partner.lastSeen < 60 * 1000 ? 'delivered' : 'sent',
    reactions: {},
  };

  db.messages.push(newMessage);

  // Add notification to partner if offline
  if (partner && Date.now() - partner.lastSeen > 30 * 1000) {
    db.notifications.push({
      id: `notif-${crypto.randomUUID()}`,
      targetUserId: partner.id,
      type: 'new_message',
      title: `${req.user!.displayName} mesaj gönderdi`,
      message: text ? (text.length > 50 ? `${text.substring(0, 50)}...` : text) : '📷 Bir fotoğraf/video gönderdi',
      metadata: { messageId: newMessage.id },
      read: false,
      createdAt: Date.now(),
    });
  }

  saveDb(db);
  res.json({ message: newMessage });
});

// Delete message
app.delete('/api/messages/:id', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDb();

  const msgIndex = db.messages.findIndex(m => m.id === id);
  if (msgIndex === -1) {
    res.status(404).json({ error: 'Mesaj bulunamadı.' });
    return;
  }

  const msg = db.messages[msgIndex];
  // Sender or admin can delete
  if (msg.senderId !== req.user!.id && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Bu mesajı silme yetkiniz yok.' });
    return;
  }

  db.messages.splice(msgIndex, 1);
  saveDb(db);
  res.json({ success: true, message: 'Mesaj silindi.' });
});

// Toggle reaction
app.post('/api/messages/:id/reaction', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { emoji } = req.body;
  if (!emoji) {
    res.status(400).json({ error: 'Emoji gereklidir.' });
    return;
  }

  const db = loadDb();
  const msg = db.messages.find(m => m.id === id);
  if (!msg) {
    res.status(404).json({ error: 'Mesaj bulunamadı.' });
    return;
  }

  if (!msg.reactions) msg.reactions = {};
  if (!msg.reactions[emoji]) msg.reactions[emoji] = [];

  const currentUserId = req.user!.id;
  const index = msg.reactions[emoji].indexOf(currentUserId);
  if (index > -1) {
    msg.reactions[emoji].splice(index, 1);
    if (msg.reactions[emoji].length === 0) {
      delete msg.reactions[emoji];
    }
  } else {
    msg.reactions[emoji].push(currentUserId);
  }

  saveDb(db);
  res.json({ reactions: msg.reactions });
});

// Update typing status
app.post('/api/messages/typing', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  userTypingMap.set(req.user!.id, Date.now());
  res.json({ ok: true });
});

// -----------------------------------------------------------------------------
// POSTS (MOMENTS / HATIRALAR) API
// -----------------------------------------------------------------------------

app.get('/api/posts', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const db = loadDb();
  // Attach author details
  const enrichedPosts = db.posts.map(p => {
    const author = db.users.find(u => u.id === p.authorId);
    return {
      ...p,
      author: author ? { id: author.id, username: author.username, displayName: author.displayName, avatar: author.avatar } : null,
    };
  });
  // Sort descending
  enrichedPosts.sort((a, b) => b.createdAt - a.createdAt);
  res.json({ posts: enrichedPosts });
});

app.post('/api/posts', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { mediaUrl, mediaType, caption, location } = req.body;
  if (!mediaUrl) {
    res.status(400).json({ error: 'Medya dosyası zorunludur.' });
    return;
  }

  const db = loadDb();
  const newPost: Post = {
    id: `post-${crypto.randomUUID()}`,
    authorId: req.user!.id,
    mediaUrl,
    mediaType: mediaType || 'photo',
    caption: caption ? caption.trim() : '',
    location: location ? location.trim() : undefined,
    createdAt: Date.now(),
    likes: [],
    comments: [],
  };

  db.posts.push(newPost);

  // Notify partner
  const partner = db.users.find(u => u.id !== req.user!.id);
  if (partner) {
    db.notifications.push({
      id: `notif-${crypto.randomUUID()}`,
      targetUserId: partner.id,
      type: 'like',
      title: `${req.user!.displayName} yeni bir anı paylaştı! 📸`,
      message: caption ? `"${caption}"` : 'Yeni fotoğraf/video akışta!',
      metadata: { postId: newPost.id },
      read: false,
      createdAt: Date.now(),
    });
  }

  saveDb(db);
  res.json({ post: newPost });
});

app.delete('/api/posts/:id', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDb();

  const postIndex = db.posts.findIndex(p => p.id === id);
  if (postIndex === -1) {
    res.status(404).json({ error: 'Paylaşım bulunamadı.' });
    return;
  }

  const post = db.posts[postIndex];
  if (post.authorId !== req.user!.id && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Bu paylaşımı silme yetkiniz yok.' });
    return;
  }

  db.posts.splice(postIndex, 1);
  saveDb(db);
  res.json({ success: true, message: 'Paylaşım silindi.' });
});

app.post('/api/posts/:id/like', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDb();

  const post = db.posts.find(p => p.id === id);
  if (!post) {
    res.status(404).json({ error: 'Paylaşım bulunamadı.' });
    return;
  }

  const currentUserId = req.user!.id;
  const index = post.likes.indexOf(currentUserId);
  if (index > -1) {
    post.likes.splice(index, 1);
  } else {
    post.likes.push(currentUserId);
    // Notify author if liked by partner
    if (post.authorId !== currentUserId) {
      db.notifications.push({
        id: `notif-${crypto.randomUUID()}`,
        targetUserId: post.authorId,
        type: 'like',
        title: '❤️ Anını Beğendi!',
        message: `${req.user!.displayName} paylaştığın fotoğrafı beğendi.`,
        metadata: { postId: post.id },
        read: false,
        createdAt: Date.now(),
      });
    }
  }

  saveDb(db);
  res.json({ likes: post.likes });
});

app.post('/api/posts/:id/comment', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { text } = req.body;
  if (!text || !text.trim()) {
    res.status(400).json({ error: 'Yorum metni gereklidir.' });
    return;
  }

  const db = loadDb();
  const post = db.posts.find(p => p.id === id);
  if (!post) {
    res.status(404).json({ error: 'Paylaşım bulunamadı.' });
    return;
  }

  const newComment: PostComment = {
    id: `comm-${crypto.randomUUID()}`,
    userId: req.user!.id,
    text: text.trim(),
    createdAt: Date.now(),
  };

  post.comments.push(newComment);

  // Notify author if commented by partner
  if (post.authorId !== req.user!.id) {
    db.notifications.push({
      id: `notif-${crypto.randomUUID()}`,
      targetUserId: post.authorId,
      type: 'comment',
      title: '💬 Yeni Yorum!',
      message: `${req.user!.displayName}: "${text.trim()}"`,
      metadata: { postId: post.id },
      read: false,
      createdAt: Date.now(),
    });
  }

  saveDb(db);
  res.json({ comment: newComment });
});

// -----------------------------------------------------------------------------
// REELS (TIKTOK STYLE VERTICAL VIDEOS) API
// -----------------------------------------------------------------------------

app.get('/api/reels', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const db = loadDb();
  const enrichedReels = db.reels.map(r => {
    const author = db.users.find(u => u.id === r.authorId);
    return {
      ...r,
      author: author ? { id: author.id, username: author.username, displayName: author.displayName, avatar: author.avatar } : null,
    };
  });
  enrichedReels.sort((a, b) => b.createdAt - a.createdAt);
  res.json({ reels: enrichedReels });
});

app.post('/api/reels', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { videoUrl, caption, soundTitle } = req.body;
  if (!videoUrl) {
    res.status(400).json({ error: 'Video dosyası zorunludur.' });
    return;
  }

  const db = loadDb();
  const newReel: Reel = {
    id: `reel-${crypto.randomUUID()}`,
    authorId: req.user!.id,
    videoUrl,
    caption: caption ? caption.trim() : '',
    soundTitle: soundTitle || 'SonsuzBiz Aşk Melodisi ❤️',
    createdAt: Date.now(),
    likes: [],
    comments: [],
  };

  db.reels.push(newReel);

  // Notify partner
  const partner = db.users.find(u => u.id !== req.user!.id);
  if (partner) {
    db.notifications.push({
      id: `notif-${crypto.randomUUID()}`,
      targetUserId: partner.id,
      type: 'like',
      title: `${req.user!.displayName} yeni bir dikey video paylaştı! 🎬`,
      message: caption ? `"${caption}"` : 'Reels akışına yeni aşk videosu eklendi!',
      metadata: { reelId: newReel.id },
      read: false,
      createdAt: Date.now(),
    });
  }

  saveDb(db);
  res.json({ reel: newReel });
});

app.delete('/api/reels/:id', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDb();

  const reelIndex = db.reels.findIndex(r => r.id === id);
  if (reelIndex === -1) {
    res.status(404).json({ error: 'Video bulunamadı.' });
    return;
  }

  const reel = db.reels[reelIndex];
  if (reel.authorId !== req.user!.id && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Bu videoyu silme yetkiniz yok.' });
    return;
  }

  db.reels.splice(reelIndex, 1);
  saveDb(db);
  res.json({ success: true, message: 'Video silindi.' });
});

app.post('/api/reels/:id/like', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDb();

  const reel = db.reels.find(r => r.id === id);
  if (!reel) {
    res.status(404).json({ error: 'Video bulunamadı.' });
    return;
  }

  const currentUserId = req.user!.id;
  const index = reel.likes.indexOf(currentUserId);
  if (index > -1) {
    reel.likes.splice(index, 1);
  } else {
    reel.likes.push(currentUserId);
    if (reel.authorId !== currentUserId) {
      db.notifications.push({
        id: `notif-${crypto.randomUUID()}`,
        targetUserId: reel.authorId,
        type: 'like',
        title: '❤️ Videonu Beğendi!',
        message: `${req.user!.displayName} paylaştığın videoyu beğendi.`,
        metadata: { reelId: reel.id },
        read: false,
        createdAt: Date.now(),
      });
    }
  }

  saveDb(db);
  res.json({ likes: reel.likes });
});

app.post('/api/reels/:id/comment', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { text } = req.body;
  if (!text || !text.trim()) {
    res.status(400).json({ error: 'Yorum metni gereklidir.' });
    return;
  }

  const db = loadDb();
  const reel = db.reels.find(r => r.id === id);
  if (!reel) {
    res.status(404).json({ error: 'Video bulunamadı.' });
    return;
  }

  const newComment: PostComment = {
    id: `comm-${crypto.randomUUID()}`,
    userId: req.user!.id,
    text: text.trim(),
    createdAt: Date.now(),
  };

  reel.comments.push(newComment);

  if (reel.authorId !== req.user!.id) {
    db.notifications.push({
      id: `notif-${crypto.randomUUID()}`,
      targetUserId: reel.authorId,
      type: 'comment',
      title: '💬 Videona Yeni Yorum!',
      message: `${req.user!.displayName}: "${text.trim()}"`,
      metadata: { reelId: reel.id },
      read: false,
      createdAt: Date.now(),
    });
  }

  saveDb(db);
  res.json({ comment: newComment });
});

// -----------------------------------------------------------------------------
// FILE UPLOAD API
// -----------------------------------------------------------------------------

app.post('/api/upload', authMiddleware, upload.single('file'), (req: AuthenticatedRequest, res: Response) => {
  if (!req.file) {
    res.status(400).json({ error: 'Yüklenecek dosya seçilmedi.' });
    return;
  }

  const fileUrl = `/uploads/${req.file.filename}`;
  res.json({
    url: fileUrl,
    filename: req.file.filename,
    mimetype: req.file.mimetype,
    size: req.file.size,
  });
});

// -----------------------------------------------------------------------------
// NOTIFICATIONS API
// -----------------------------------------------------------------------------

app.get('/api/notifications', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const db = loadDb();
  const userNotifications = db.notifications.filter(n => n.targetUserId === req.user!.id);
  userNotifications.sort((a, b) => b.createdAt - a.createdAt);
  res.json({ notifications: userNotifications });
});

app.post('/api/notifications/:id/read', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDb();
  const notif = db.notifications.find(n => n.id === id && n.targetUserId === req.user!.id);
  if (notif) {
    notif.read = true;
    saveDb(db);
  }
  res.json({ success: true });
});

app.post('/api/notifications/read-all', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const db = loadDb();
  db.notifications.forEach(n => {
    if (n.targetUserId === req.user!.id) n.read = true;
  });
  saveDb(db);
  res.json({ success: true });
});

// -----------------------------------------------------------------------------
// ADMIN PANEL API (STRICT ROLE VALIDATION)
// -----------------------------------------------------------------------------

app.get('/api/admin/dashboard', authMiddleware, adminOnlyMiddleware, (_req: AuthenticatedRequest, res: Response) => {
  const db = loadDb();

  const users = db.users.map(u => {
    const { passwordHash: _, salt: __, ...safe } = u;
    return { ...safe, isOnline: Date.now() - u.lastSeen < 3 * 60 * 1000 };
  });

  // Calculate approximate storage usage
  let totalUploadSizeBytes = 0;
  try {
    const files = fs.readdirSync(UPLOADS_DIR);
    for (const f of files) {
      const stat = fs.statSync(path.join(UPLOADS_DIR, f));
      totalUploadSizeBytes += stat.size;
    }
  } catch (e) {
    // ignore
  }

  res.json({
    users,
    inviteCodes: db.inviteCodes,
    totalPosts: db.posts.length,
    totalReels: db.reels.length,
    totalMessages: db.messages.length,
    totalUploadSizeBytes,
    storageMB: (totalUploadSizeBytes / (1024 * 1024)).toFixed(2),
  });
});

app.post('/api/admin/generate-invite', authMiddleware, adminOnlyMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const db = loadDb();
  if (db.users.length >= 2) {
    res.status(403).json({ error: '2 kullanıcı sınırı dolmuştur. İkinci bir hesap zaten mevcut.' });
    return;
  }

  const codeSuffix = Math.floor(100000 + Math.random() * 900000).toString();
  const inviteCodeStr = `BIZ-${codeSuffix.substring(0, 4)}`;

  const newCode: InviteCode = {
    id: `inv-${crypto.randomUUID()}`,
    code: inviteCodeStr,
    createdBy: req.user!.id,
    createdAt: Date.now(),
    expiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 hours for admin created code
    used: false,
    usedBy: null,
    usedAt: null,
  };

  db.inviteCodes.push(newCode);
  saveDb(db);

  res.json({ inviteCode: newCode, message: 'Yeni davet kodu üretildi.' });
});

app.delete('/api/admin/invite-codes/:id', authMiddleware, adminOnlyMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDb();
  const idx = db.inviteCodes.findIndex(c => c.id === id);
  if (idx !== -1) {
    db.inviteCodes.splice(idx, 1);
    saveDb(db);
  }
  res.json({ success: true, message: 'Davet kodu iptal edildi.' });
});

app.post('/api/admin/toggle-user/:userId', authMiddleware, adminOnlyMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { userId } = req.params;
  const db = loadDb();
  const user = db.users.find(u => u.id === userId);

  if (!user) {
    res.status(404).json({ error: 'Kullanıcı bulunamadı.' });
    return;
  }

  if (user.role === 'admin') {
    res.status(400).json({ error: 'Yönetici hesabı devre dışı bırakılamaz.' });
    return;
  }

  user.isActive = !user.isActive;
  // If deactivated, kill user's active sessions
  if (!user.isActive) {
    db.sessions = db.sessions.filter(s => s.userId !== user.id);
  }

  saveDb(db);
  res.json({ user, message: user.isActive ? 'Kullanıcı aktifleştirildi.' : 'Kullanıcı devre dışı bırakıldı.' });
});

app.delete('/api/admin/users/:userId', authMiddleware, adminOnlyMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { userId } = req.params;
  const db = loadDb();
  const userIndex = db.users.findIndex(u => u.id === userId);

  if (userIndex === -1) {
    res.status(404).json({ error: 'Kullanıcı bulunamadı.' });
    return;
  }

  if (db.users[userIndex].role === 'admin') {
    res.status(400).json({ error: 'Yönetici hesabı silinemez.' });
    return;
  }

  // Remove partner and all partner sessions
  db.users.splice(userIndex, 1);
  db.sessions = db.sessions.filter(s => s.userId !== userId);
  saveDb(db);

  res.json({ success: true, message: 'Kullanıcı hesabı silindi. Artık yeni davet kodu ile partner eklenebilir.' });
});

// Admin reset partner password
app.post('/api/admin/reset-partner-password', authMiddleware, adminOnlyMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { newPassword } = req.body;
  if (!newPassword || newPassword.length < 6) {
    res.status(400).json({ error: 'Yeni şifre en az 6 karakter olmalıdır.' });
    return;
  }

  const db = loadDb();
  const partner = db.users.find(u => u.role === 'partner');
  if (!partner) {
    res.status(404).json({ error: 'Sevgilinizin hesabı henüz kurulmamış.' });
    return;
  }

  const { hash, salt } = hashPassword(newPassword);
  partner.passwordHash = hash;
  partner.salt = salt;
  // Invalidate partner old sessions so they log in with new password
  db.sessions = db.sessions.filter(s => s.userId !== partner.id);
  saveDb(db);

  res.json({ success: true, message: 'Sevgilinizin şifresi sıfırlandı. Yeni şifreyle giriş yapabilir.' });
});

// -----------------------------------------------------------------------------
// VITE DEV SERVER / PRODUCTION STATIC SERVING
// -----------------------------------------------------------------------------

async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const server = http.createServer(app);
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[SonsuzBiz] Sunucu http://0.0.0.0:${PORT} adresinde aktif.`);
  });
}

startServer().catch(err => {
  console.error('Server başlatılamadı:', err);
  process.exit(1);
});
